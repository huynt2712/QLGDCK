﻿namespace QLGDCK
{
    partial class FormNhaDauTu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.LBCongty = new System.Windows.Forms.Label();
            this.LBQuyen = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LBTen = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LBMa = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnXemBaoCao = new System.Windows.Forms.Button();
            this.btnThoatNDT = new System.Windows.Forms.Button();
            this.dgvTraCuu = new System.Windows.Forms.DataGridView();
            this.MaLD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayGio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaTKNH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaoDich = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongDat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaDat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongKhop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaKhop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbTraCuu = new System.Windows.Forms.GroupBox();
            this.txtMaTKNHSD = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTenNHSD = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.cmbMaNH = new System.Windows.Forms.ComboBox();
            this.txtSoduGD = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtTenNDTSD = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnThanhTien = new System.Windows.Forms.Button();
            this.btnThoatDLM = new System.Windows.Forms.Button();
            this.btnDL = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dtpNgayDat = new System.Windows.Forms.DateTimePicker();
            this.txtDLMua = new System.Windows.Forms.TextBox();
            this.txtMaCTCK = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtTenLGD = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txtMKDL = new System.Windows.Forms.TextBox();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.txtPhiGD = new System.Windows.Forms.TextBox();
            this.txtGiaDat = new System.Windows.Forms.TextBox();
            this.txtSoLuongDat = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtMaDL = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cmbTKNH = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbLenhMP = new System.Windows.Forms.RadioButton();
            this.rbLenhLO = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbNgayCP = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtTenCP = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.cmbMaCP = new System.Windows.Forms.ComboBox();
            this.txtGiaSan = new System.Windows.Forms.TextBox();
            this.txtGiaTran = new System.Windows.Forms.TextBox();
            this.txtSoDu = new System.Windows.Forms.TextBox();
            this.txtGiaThamChieu = new System.Windows.Forms.TextBox();
            this.txtMaSGD = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnThanhtienBan = new System.Windows.Forms.Button();
            this.btnThoatBan = new System.Windows.Forms.Button();
            this.btnDLBan = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dtpNgayDatBan = new System.Windows.Forms.DateTimePicker();
            this.txtDLBan = new System.Windows.Forms.TextBox();
            this.txtMaCTCKBan = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtTenLGDBan = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtMKDLBan = new System.Windows.Forms.TextBox();
            this.txtTongTienBan = new System.Windows.Forms.TextBox();
            this.txtPhiGDBan = new System.Windows.Forms.TextBox();
            this.txtGiaDatBan = new System.Windows.Forms.TextBox();
            this.txtSoLuongDatBan = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtMaDLBan = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.cmbTKNHBan = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rbLenhMPBan = new System.Windows.Forms.RadioButton();
            this.rbLenhLOBan = new System.Windows.Forms.RadioButton();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cmbNgayCPBan = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtTenCPBan = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cmbMaCPBan = new System.Windows.Forms.ComboBox();
            this.txtGiaSanBan = new System.Windows.Forms.TextBox();
            this.txtGiaTranBan = new System.Windows.Forms.TextBox();
            this.txtSoDuBan = new System.Windows.Forms.TextBox();
            this.txtGiaThamChieuBan = new System.Windows.Forms.TextBox();
            this.txtMaSGDBan = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.txtTenCPBC = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.btnBaoCaoChiTiet = new System.Windows.Forms.Button();
            this.btnBaoCaoSaoKe = new System.Windows.Forms.Button();
            this.cmbMaCPBC = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.dtpTuNgay = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.dtpDenNgay = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTraCuu)).BeginInit();
            this.gbTraCuu.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.LBCongty);
            this.panel1.Controls.Add(this.LBQuyen);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.LBTen);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.LBMa);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 565);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(865, 98);
            this.panel1.TabIndex = 1;
            // 
            // LBCongty
            // 
            this.LBCongty.AutoSize = true;
            this.LBCongty.Location = new System.Drawing.Point(684, 44);
            this.LBCongty.Name = "LBCongty";
            this.LBCongty.Size = new System.Drawing.Size(35, 13);
            this.LBCongty.TabIndex = 6;
            this.LBCongty.Text = "label7";
            // 
            // LBQuyen
            // 
            this.LBQuyen.AutoSize = true;
            this.LBQuyen.Location = new System.Drawing.Point(503, 44);
            this.LBQuyen.Name = "LBQuyen";
            this.LBQuyen.Size = new System.Drawing.Size(35, 13);
            this.LBQuyen.TabIndex = 5;
            this.LBQuyen.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(454, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Quyền:";
            // 
            // LBTen
            // 
            this.LBTen.AutoSize = true;
            this.LBTen.Location = new System.Drawing.Point(253, 44);
            this.LBTen.Name = "LBTen";
            this.LBTen.Size = new System.Drawing.Size(35, 13);
            this.LBTen.TabIndex = 3;
            this.LBTen.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(189, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Họ và tên:";
            // 
            // LBMa
            // 
            this.LBMa.AutoSize = true;
            this.LBMa.Location = new System.Drawing.Point(40, 44);
            this.LBMa.Name = "LBMa";
            this.LBMa.Size = new System.Drawing.Size(35, 13);
            this.LBMa.TabIndex = 1;
            this.LBMa.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnXemBaoCao);
            this.tabPage3.Controls.Add(this.btnThoatNDT);
            this.tabPage3.Controls.Add(this.dgvTraCuu);
            this.tabPage3.Controls.Add(this.gbTraCuu);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(861, 533);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tra cứu số dư";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnXemBaoCao
            // 
            this.btnXemBaoCao.Location = new System.Drawing.Point(502, 25);
            this.btnXemBaoCao.Margin = new System.Windows.Forms.Padding(2);
            this.btnXemBaoCao.Name = "btnXemBaoCao";
            this.btnXemBaoCao.Size = new System.Drawing.Size(94, 23);
            this.btnXemBaoCao.TabIndex = 7;
            this.btnXemBaoCao.Text = "Xem Báo Cáo";
            this.btnXemBaoCao.UseVisualStyleBackColor = true;
            this.btnXemBaoCao.Click += new System.EventHandler(this.btnXemBaoCao_Click);
            // 
            // btnThoatNDT
            // 
            this.btnThoatNDT.Location = new System.Drawing.Point(271, 25);
            this.btnThoatNDT.Margin = new System.Windows.Forms.Padding(2);
            this.btnThoatNDT.Name = "btnThoatNDT";
            this.btnThoatNDT.Size = new System.Drawing.Size(61, 23);
            this.btnThoatNDT.TabIndex = 6;
            this.btnThoatNDT.Text = "Thoát";
            this.btnThoatNDT.UseVisualStyleBackColor = true;
            this.btnThoatNDT.Click += new System.EventHandler(this.btnThoatNDT_Click);
            // 
            // dgvTraCuu
            // 
            this.dgvTraCuu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTraCuu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaLD,
            this.NgayGio,
            this.MaTKNH,
            this.GiaoDich,
            this.MaCP,
            this.SoLuongDat,
            this.GiaDat,
            this.SoLuongKhop,
            this.GiaKhop,
            this.TenTT});
            this.dgvTraCuu.Location = new System.Drawing.Point(112, 288);
            this.dgvTraCuu.Margin = new System.Windows.Forms.Padding(2);
            this.dgvTraCuu.Name = "dgvTraCuu";
            this.dgvTraCuu.RowHeadersWidth = 51;
            this.dgvTraCuu.RowTemplate.Height = 24;
            this.dgvTraCuu.Size = new System.Drawing.Size(651, 224);
            this.dgvTraCuu.TabIndex = 5;
            // 
            // MaLD
            // 
            this.MaLD.DataPropertyName = "MaLD";
            this.MaLD.HeaderText = "Mã lệnh đặt";
            this.MaLD.Name = "MaLD";
            // 
            // NgayGio
            // 
            this.NgayGio.DataPropertyName = "NgayGio";
            this.NgayGio.HeaderText = "Ngày giờ đặt";
            this.NgayGio.Name = "NgayGio";
            // 
            // MaTKNH
            // 
            this.MaTKNH.DataPropertyName = "MaTKNH";
            this.MaTKNH.HeaderText = "Mã tài khoản ngân hàng";
            this.MaTKNH.Name = "MaTKNH";
            this.MaTKNH.Width = 150;
            // 
            // GiaoDich
            // 
            this.GiaoDich.DataPropertyName = "TenLoaiGiaoDich";
            this.GiaoDich.HeaderText = "Giao dịch";
            this.GiaoDich.Name = "GiaoDich";
            // 
            // MaCP
            // 
            this.MaCP.DataPropertyName = "MaCP";
            this.MaCP.HeaderText = "Mã cổ phiếu";
            this.MaCP.Name = "MaCP";
            // 
            // SoLuongDat
            // 
            this.SoLuongDat.DataPropertyName = "SoLuongDat";
            this.SoLuongDat.HeaderText = "Số lượng đặt";
            this.SoLuongDat.Name = "SoLuongDat";
            // 
            // GiaDat
            // 
            this.GiaDat.DataPropertyName = "GiaDat";
            this.GiaDat.HeaderText = "Giá đặt";
            this.GiaDat.Name = "GiaDat";
            // 
            // SoLuongKhop
            // 
            this.SoLuongKhop.DataPropertyName = "SoLuongKhop";
            this.SoLuongKhop.HeaderText = "Số lượng khớp";
            this.SoLuongKhop.Name = "SoLuongKhop";
            // 
            // GiaKhop
            // 
            this.GiaKhop.DataPropertyName = "GiaKhop";
            this.GiaKhop.HeaderText = "Giá Khớp";
            this.GiaKhop.Name = "GiaKhop";
            // 
            // TenTT
            // 
            this.TenTT.DataPropertyName = "TenTT";
            this.TenTT.HeaderText = "Trạng thái";
            this.TenTT.Name = "TenTT";
            // 
            // gbTraCuu
            // 
            this.gbTraCuu.Controls.Add(this.txtMaTKNHSD);
            this.gbTraCuu.Controls.Add(this.label11);
            this.gbTraCuu.Controls.Add(this.txtTenNHSD);
            this.gbTraCuu.Controls.Add(this.label46);
            this.gbTraCuu.Controls.Add(this.cmbMaNH);
            this.gbTraCuu.Controls.Add(this.txtSoduGD);
            this.gbTraCuu.Controls.Add(this.label47);
            this.gbTraCuu.Controls.Add(this.label48);
            this.gbTraCuu.Controls.Add(this.txtTenNDTSD);
            this.gbTraCuu.Controls.Add(this.label10);
            this.gbTraCuu.Location = new System.Drawing.Point(112, 74);
            this.gbTraCuu.Margin = new System.Windows.Forms.Padding(2);
            this.gbTraCuu.Name = "gbTraCuu";
            this.gbTraCuu.Padding = new System.Windows.Forms.Padding(2);
            this.gbTraCuu.Size = new System.Drawing.Size(651, 182);
            this.gbTraCuu.TabIndex = 4;
            this.gbTraCuu.TabStop = false;
            // 
            // txtMaTKNHSD
            // 
            this.txtMaTKNHSD.Location = new System.Drawing.Point(430, 32);
            this.txtMaTKNHSD.Name = "txtMaTKNHSD";
            this.txtMaTKNHSD.Size = new System.Drawing.Size(100, 21);
            this.txtMaTKNHSD.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(289, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "Mã tài khoản ngân hàng:";
            // 
            // txtTenNHSD
            // 
            this.txtTenNHSD.Location = new System.Drawing.Point(390, 88);
            this.txtTenNHSD.Name = "txtTenNHSD";
            this.txtTenNHSD.Size = new System.Drawing.Size(232, 21);
            this.txtTenNHSD.TabIndex = 15;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(23, 91);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(79, 13);
            this.label46.TabIndex = 14;
            this.label46.Text = "Mã ngân hàng:";
            // 
            // cmbMaNH
            // 
            this.cmbMaNH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaNH.FormattingEnabled = true;
            this.cmbMaNH.Location = new System.Drawing.Point(118, 88);
            this.cmbMaNH.Name = "cmbMaNH";
            this.cmbMaNH.Size = new System.Drawing.Size(100, 21);
            this.cmbMaNH.TabIndex = 13;
            this.cmbMaNH.SelectedIndexChanged += new System.EventHandler(this.cmbMaNH_SelectedIndexChanged);
            // 
            // txtSoduGD
            // 
            this.txtSoduGD.Location = new System.Drawing.Point(171, 136);
            this.txtSoduGD.Name = "txtSoduGD";
            this.txtSoduGD.Size = new System.Drawing.Size(100, 21);
            this.txtSoduGD.TabIndex = 12;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(23, 139);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(131, 13);
            this.label47.TabIndex = 11;
            this.label47.Text = "Số dư cho phép giao dịch:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(289, 91);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(83, 13);
            this.label48.TabIndex = 10;
            this.label48.Text = "Tên ngân hàng:";
            // 
            // txtTenNDTSD
            // 
            this.txtTenNDTSD.Location = new System.Drawing.Point(146, 32);
            this.txtTenNDTSD.Margin = new System.Windows.Forms.Padding(2);
            this.txtTenNDTSD.Name = "txtTenNDTSD";
            this.txtTenNDTSD.Size = new System.Drawing.Size(104, 21);
            this.txtTenNDTSD.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 35);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Tên nhà đàu tư";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnThanhTien);
            this.tabPage1.Controls.Add(this.btnThoatDLM);
            this.tabPage1.Controls.Add(this.btnDL);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(861, 533);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Đặt lệnh mua";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnThanhTien
            // 
            this.btnThanhTien.Location = new System.Drawing.Point(310, 486);
            this.btnThanhTien.Name = "btnThanhTien";
            this.btnThanhTien.Size = new System.Drawing.Size(75, 30);
            this.btnThanhTien.TabIndex = 23;
            this.btnThanhTien.Text = "Thành tiền";
            this.btnThanhTien.UseVisualStyleBackColor = true;
            this.btnThanhTien.Click += new System.EventHandler(this.btnThanhTien_Click);
            // 
            // btnThoatDLM
            // 
            this.btnThoatDLM.Location = new System.Drawing.Point(498, 486);
            this.btnThoatDLM.Name = "btnThoatDLM";
            this.btnThoatDLM.Size = new System.Drawing.Size(75, 30);
            this.btnThoatDLM.TabIndex = 5;
            this.btnThoatDLM.Text = "Thoát";
            this.btnThoatDLM.UseVisualStyleBackColor = true;
            this.btnThoatDLM.Click += new System.EventHandler(this.btnThoatDLM_Click);
            // 
            // btnDL
            // 
            this.btnDL.Location = new System.Drawing.Point(148, 486);
            this.btnDL.Name = "btnDL";
            this.btnDL.Size = new System.Drawing.Size(84, 30);
            this.btnDL.TabIndex = 4;
            this.btnDL.Text = "Đặt lệnh mua";
            this.btnDL.UseVisualStyleBackColor = true;
            this.btnDL.Click += new System.EventHandler(this.btnDL_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dtpNgayDat);
            this.groupBox4.Controls.Add(this.txtDLMua);
            this.groupBox4.Controls.Add(this.txtMaCTCK);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.txtTenLGD);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.label39);
            this.groupBox4.Controls.Add(this.txtMKDL);
            this.groupBox4.Controls.Add(this.txtTongTien);
            this.groupBox4.Controls.Add(this.txtPhiGD);
            this.groupBox4.Controls.Add(this.txtGiaDat);
            this.groupBox4.Controls.Add(this.txtSoLuongDat);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Location = new System.Drawing.Point(18, 272);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(827, 206);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            // 
            // dtpNgayDat
            // 
            this.dtpNgayDat.CustomFormat = "yyyy-MM-dd HH:MM:ss";
            this.dtpNgayDat.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayDat.Location = new System.Drawing.Point(414, 15);
            this.dtpNgayDat.Name = "dtpNgayDat";
            this.dtpNgayDat.Size = new System.Drawing.Size(208, 21);
            this.dtpNgayDat.TabIndex = 33;
            this.dtpNgayDat.ValueChanged += new System.EventHandler(this.dtpNgayDat_ValueChanged);
            // 
            // txtDLMua
            // 
            this.txtDLMua.Location = new System.Drawing.Point(414, 61);
            this.txtDLMua.Name = "txtDLMua";
            this.txtDLMua.Size = new System.Drawing.Size(100, 21);
            this.txtDLMua.TabIndex = 22;
            this.txtDLMua.Text = "GDM";
            // 
            // txtMaCTCK
            // 
            this.txtMaCTCK.Location = new System.Drawing.Point(486, 103);
            this.txtMaCTCK.Name = "txtMaCTCK";
            this.txtMaCTCK.Size = new System.Drawing.Size(100, 21);
            this.txtMaCTCK.TabIndex = 20;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(315, 106);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(129, 13);
            this.label19.TabIndex = 19;
            this.label19.Text = "Mã công ty chứng khoán:";
            // 
            // txtTenLGD
            // 
            this.txtTenLGD.Location = new System.Drawing.Point(599, 61);
            this.txtTenLGD.Name = "txtTenLGD";
            this.txtTenLGD.Size = new System.Drawing.Size(115, 21);
            this.txtTenLGD.TabIndex = 18;
            this.txtTenLGD.Text = "Giao dịch mua";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(315, 20);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(72, 13);
            this.label34.TabIndex = 15;
            this.label34.Text = "Ngày giờ đặt:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(315, 64);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(52, 13);
            this.label39.TabIndex = 3;
            this.label39.Text = "Đặt lệnh:";
            // 
            // txtMKDL
            // 
            this.txtMKDL.Location = new System.Drawing.Point(176, 162);
            this.txtMKDL.Name = "txtMKDL";
            this.txtMKDL.PasswordChar = '*';
            this.txtMKDL.Size = new System.Drawing.Size(100, 21);
            this.txtMKDL.TabIndex = 9;
            // 
            // txtTongTien
            // 
            this.txtTongTien.Location = new System.Drawing.Point(176, 124);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(100, 21);
            this.txtTongTien.TabIndex = 8;
            // 
            // txtPhiGD
            // 
            this.txtPhiGD.Location = new System.Drawing.Point(176, 88);
            this.txtPhiGD.Name = "txtPhiGD";
            this.txtPhiGD.Size = new System.Drawing.Size(100, 21);
            this.txtPhiGD.TabIndex = 7;
            // 
            // txtGiaDat
            // 
            this.txtGiaDat.Location = new System.Drawing.Point(176, 56);
            this.txtGiaDat.Name = "txtGiaDat";
            this.txtGiaDat.Size = new System.Drawing.Size(100, 21);
            this.txtGiaDat.TabIndex = 6;
            // 
            // txtSoLuongDat
            // 
            this.txtSoLuongDat.Location = new System.Drawing.Point(176, 18);
            this.txtSoLuongDat.Name = "txtSoLuongDat";
            this.txtSoLuongDat.Size = new System.Drawing.Size(100, 21);
            this.txtSoLuongDat.TabIndex = 5;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(53, 165);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(97, 13);
            this.label32.TabIndex = 4;
            this.label32.Text = "Mật khẩu đặt lệnh:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(53, 127);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(70, 13);
            this.label31.TabIndex = 3;
            this.label31.Text = "Tổng số tiền:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(53, 91);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(70, 13);
            this.label25.TabIndex = 2;
            this.label25.Text = "Phí giao dịch:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(53, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Giá:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(53, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Số lượng:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtMaDL);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.cmbTKNH);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Location = new System.Drawing.Point(18, 219);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(827, 46);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // txtMaDL
            // 
            this.txtMaDL.Location = new System.Drawing.Point(490, 18);
            this.txtMaDL.Name = "txtMaDL";
            this.txtMaDL.Size = new System.Drawing.Size(106, 21);
            this.txtMaDL.TabIndex = 3;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(405, 21);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Mã đặt lệnh:";
            // 
            // cmbTKNH
            // 
            this.cmbTKNH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTKNH.FormattingEnabled = true;
            this.cmbTKNH.Location = new System.Drawing.Point(179, 18);
            this.cmbTKNH.Name = "cmbTKNH";
            this.cmbTKNH.Size = new System.Drawing.Size(121, 21);
            this.cmbTKNH.TabIndex = 1;
            this.cmbTKNH.SelectedIndexChanged += new System.EventHandler(this.cmbTKNH_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(30, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(111, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Tài khoản ngân hàng:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbLenhMP);
            this.groupBox2.Controls.Add(this.rbLenhLO);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Location = new System.Drawing.Point(18, 145);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(827, 67);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // rbLenhMP
            // 
            this.rbLenhMP.AutoSize = true;
            this.rbLenhMP.Location = new System.Drawing.Point(145, 43);
            this.rbLenhMP.Name = "rbLenhMP";
            this.rbLenhMP.Size = new System.Drawing.Size(124, 17);
            this.rbLenhMP.TabIndex = 2;
            this.rbLenhMP.TabStop = true;
            this.rbLenhMP.Text = "Lệnh thị trường (MP)";
            this.rbLenhMP.UseVisualStyleBackColor = true;
            // 
            // rbLenhLO
            // 
            this.rbLenhLO.AutoSize = true;
            this.rbLenhLO.Location = new System.Drawing.Point(145, 20);
            this.rbLenhLO.Name = "rbLenhLO";
            this.rbLenhLO.Size = new System.Drawing.Size(131, 17);
            this.rbLenhLO.TabIndex = 1;
            this.rbLenhLO.TabStop = true;
            this.rbLenhLO.Text = "Lệnh đặt giới hạn (LO)";
            this.rbLenhLO.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(27, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "Loại lệnh:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbNgayCP);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.txtTenCP);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.cmbMaCP);
            this.groupBox1.Controls.Add(this.txtGiaSan);
            this.groupBox1.Controls.Add(this.txtGiaTran);
            this.groupBox1.Controls.Add(this.txtSoDu);
            this.groupBox1.Controls.Add(this.txtGiaThamChieu);
            this.groupBox1.Controls.Add(this.txtMaSGD);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(18, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(827, 119);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // cmbNgayCP
            // 
            this.cmbNgayCP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNgayCP.FormattingEnabled = true;
            this.cmbNgayCP.Location = new System.Drawing.Point(630, 54);
            this.cmbNgayCP.Name = "cmbNgayCP";
            this.cmbNgayCP.Size = new System.Drawing.Size(158, 21);
            this.cmbNgayCP.TabIndex = 15;
            this.cmbNgayCP.SelectedIndexChanged += new System.EventHandler(this.cmbNgayCP_SelectedIndexChanged);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(526, 57);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(96, 13);
            this.label38.TabIndex = 3;
            this.label38.Text = "Ngày giờ cổ phiếu:";
            // 
            // txtTenCP
            // 
            this.txtTenCP.Location = new System.Drawing.Point(424, 90);
            this.txtTenCP.Name = "txtTenCP";
            this.txtTenCP.Size = new System.Drawing.Size(279, 21);
            this.txtTenCP.TabIndex = 14;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(320, 93);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(72, 13);
            this.label37.TabIndex = 13;
            this.label37.Text = "Tên cổ phiếu:";
            // 
            // cmbMaCP
            // 
            this.cmbMaCP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaCP.FormattingEnabled = true;
            this.cmbMaCP.Location = new System.Drawing.Point(393, 18);
            this.cmbMaCP.Name = "cmbMaCP";
            this.cmbMaCP.Size = new System.Drawing.Size(100, 21);
            this.cmbMaCP.TabIndex = 12;
            this.cmbMaCP.SelectedIndexChanged += new System.EventHandler(this.cmbMaCP_SelectedIndexChanged);
            // 
            // txtGiaSan
            // 
            this.txtGiaSan.Location = new System.Drawing.Point(393, 54);
            this.txtGiaSan.Name = "txtGiaSan";
            this.txtGiaSan.Size = new System.Drawing.Size(100, 21);
            this.txtGiaSan.TabIndex = 11;
            // 
            // txtGiaTran
            // 
            this.txtGiaTran.Location = new System.Drawing.Point(599, 18);
            this.txtGiaTran.Name = "txtGiaTran";
            this.txtGiaTran.Size = new System.Drawing.Size(100, 21);
            this.txtGiaTran.TabIndex = 10;
            // 
            // txtSoDu
            // 
            this.txtSoDu.Location = new System.Drawing.Point(179, 90);
            this.txtSoDu.Name = "txtSoDu";
            this.txtSoDu.Size = new System.Drawing.Size(100, 21);
            this.txtSoDu.TabIndex = 8;
            // 
            // txtGiaThamChieu
            // 
            this.txtGiaThamChieu.Location = new System.Drawing.Point(179, 54);
            this.txtGiaThamChieu.Name = "txtGiaThamChieu";
            this.txtGiaThamChieu.Size = new System.Drawing.Size(100, 21);
            this.txtGiaThamChieu.TabIndex = 7;
            // 
            // txtMaSGD
            // 
            this.txtMaSGD.Location = new System.Drawing.Point(179, 18);
            this.txtMaSGD.Name = "txtMaSGD";
            this.txtMaSGD.Size = new System.Drawing.Size(100, 21);
            this.txtMaSGD.TabIndex = 6;
            this.txtMaSGD.Text = "HNX";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(320, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Giá sàn:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(526, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Giá trần:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(320, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Mã cổ phiếu:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 93);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Số dư được phép giao dịch:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Giá tham chiếu:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã sàn giao dịch:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(869, 559);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnThanhtienBan);
            this.tabPage2.Controls.Add(this.btnThoatBan);
            this.tabPage2.Controls.Add(this.btnDLBan);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(861, 533);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Đặt lệnh bán";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnThanhtienBan
            // 
            this.btnThanhtienBan.Location = new System.Drawing.Point(336, 485);
            this.btnThanhtienBan.Name = "btnThanhtienBan";
            this.btnThanhtienBan.Size = new System.Drawing.Size(75, 31);
            this.btnThanhtienBan.TabIndex = 23;
            this.btnThanhtienBan.Text = "Thành tiền";
            this.btnThanhtienBan.UseVisualStyleBackColor = true;
            this.btnThanhtienBan.Click += new System.EventHandler(this.btnThanhtienBan_Click);
            // 
            // btnThoatBan
            // 
            this.btnThoatBan.Location = new System.Drawing.Point(503, 485);
            this.btnThoatBan.Name = "btnThoatBan";
            this.btnThoatBan.Size = new System.Drawing.Size(75, 30);
            this.btnThoatBan.TabIndex = 11;
            this.btnThoatBan.Text = "Thoát";
            this.btnThoatBan.UseVisualStyleBackColor = true;
            this.btnThoatBan.Click += new System.EventHandler(this.btnThoatBan_Click);
            // 
            // btnDLBan
            // 
            this.btnDLBan.Location = new System.Drawing.Point(153, 485);
            this.btnDLBan.Name = "btnDLBan";
            this.btnDLBan.Size = new System.Drawing.Size(84, 30);
            this.btnDLBan.TabIndex = 10;
            this.btnDLBan.Text = "Đặt lệnh bán";
            this.btnDLBan.UseVisualStyleBackColor = true;
            this.btnDLBan.Click += new System.EventHandler(this.btnDLBan_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dtpNgayDatBan);
            this.groupBox5.Controls.Add(this.txtDLBan);
            this.groupBox5.Controls.Add(this.txtMaCTCKBan);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.txtTenLGDBan);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.txtMKDLBan);
            this.groupBox5.Controls.Add(this.txtTongTienBan);
            this.groupBox5.Controls.Add(this.txtPhiGDBan);
            this.groupBox5.Controls.Add(this.txtGiaDatBan);
            this.groupBox5.Controls.Add(this.txtSoLuongDatBan);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Location = new System.Drawing.Point(18, 272);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(827, 206);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            // 
            // dtpNgayDatBan
            // 
            this.dtpNgayDatBan.CustomFormat = "yyyy-MM-dd HH:MM:ss";
            this.dtpNgayDatBan.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayDatBan.Location = new System.Drawing.Point(414, 15);
            this.dtpNgayDatBan.Name = "dtpNgayDatBan";
            this.dtpNgayDatBan.Size = new System.Drawing.Size(208, 21);
            this.dtpNgayDatBan.TabIndex = 33;
            this.dtpNgayDatBan.ValueChanged += new System.EventHandler(this.dtpNgayDatBan_ValueChanged);
            // 
            // txtDLBan
            // 
            this.txtDLBan.Location = new System.Drawing.Point(414, 61);
            this.txtDLBan.Name = "txtDLBan";
            this.txtDLBan.Size = new System.Drawing.Size(100, 21);
            this.txtDLBan.TabIndex = 22;
            this.txtDLBan.Text = "GDB";
            // 
            // txtMaCTCKBan
            // 
            this.txtMaCTCKBan.Location = new System.Drawing.Point(486, 103);
            this.txtMaCTCKBan.Name = "txtMaCTCKBan";
            this.txtMaCTCKBan.Size = new System.Drawing.Size(100, 21);
            this.txtMaCTCKBan.TabIndex = 20;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(315, 106);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(129, 13);
            this.label20.TabIndex = 19;
            this.label20.Text = "Mã công ty chứng khoán:";
            // 
            // txtTenLGDBan
            // 
            this.txtTenLGDBan.Location = new System.Drawing.Point(599, 61);
            this.txtTenLGDBan.Name = "txtTenLGDBan";
            this.txtTenLGDBan.Size = new System.Drawing.Size(115, 21);
            this.txtTenLGDBan.TabIndex = 18;
            this.txtTenLGDBan.Text = "Giao dịch bán";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(315, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 13);
            this.label21.TabIndex = 15;
            this.label21.Text = "Ngày giờ đặt:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(315, 64);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 13);
            this.label22.TabIndex = 3;
            this.label22.Text = "Đặt lệnh:";
            // 
            // txtMKDLBan
            // 
            this.txtMKDLBan.Location = new System.Drawing.Point(176, 162);
            this.txtMKDLBan.Name = "txtMKDLBan";
            this.txtMKDLBan.PasswordChar = '*';
            this.txtMKDLBan.Size = new System.Drawing.Size(100, 21);
            this.txtMKDLBan.TabIndex = 9;
            // 
            // txtTongTienBan
            // 
            this.txtTongTienBan.Location = new System.Drawing.Point(176, 124);
            this.txtTongTienBan.Name = "txtTongTienBan";
            this.txtTongTienBan.Size = new System.Drawing.Size(100, 21);
            this.txtTongTienBan.TabIndex = 8;
            // 
            // txtPhiGDBan
            // 
            this.txtPhiGDBan.Location = new System.Drawing.Point(176, 88);
            this.txtPhiGDBan.Name = "txtPhiGDBan";
            this.txtPhiGDBan.Size = new System.Drawing.Size(100, 21);
            this.txtPhiGDBan.TabIndex = 7;
            // 
            // txtGiaDatBan
            // 
            this.txtGiaDatBan.Location = new System.Drawing.Point(176, 56);
            this.txtGiaDatBan.Name = "txtGiaDatBan";
            this.txtGiaDatBan.Size = new System.Drawing.Size(100, 21);
            this.txtGiaDatBan.TabIndex = 6;
            // 
            // txtSoLuongDatBan
            // 
            this.txtSoLuongDatBan.Location = new System.Drawing.Point(176, 18);
            this.txtSoLuongDatBan.Name = "txtSoLuongDatBan";
            this.txtSoLuongDatBan.Size = new System.Drawing.Size(100, 21);
            this.txtSoLuongDatBan.TabIndex = 5;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(53, 165);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(97, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "Mật khẩu đặt lệnh:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(53, 127);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(70, 13);
            this.label24.TabIndex = 3;
            this.label24.Text = "Tổng số tiền:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(53, 91);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 13);
            this.label26.TabIndex = 2;
            this.label26.Text = "Phí giao dịch:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(53, 56);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(26, 13);
            this.label27.TabIndex = 1;
            this.label27.Text = "Giá:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(53, 21);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "Số lượng:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtMaDLBan);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.cmbTKNHBan);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Location = new System.Drawing.Point(18, 219);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(827, 46);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            // 
            // txtMaDLBan
            // 
            this.txtMaDLBan.Location = new System.Drawing.Point(490, 18);
            this.txtMaDLBan.Name = "txtMaDLBan";
            this.txtMaDLBan.Size = new System.Drawing.Size(106, 21);
            this.txtMaDLBan.TabIndex = 3;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(405, 21);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(67, 13);
            this.label29.TabIndex = 2;
            this.label29.Text = "Mã đặt lệnh:";
            // 
            // cmbTKNHBan
            // 
            this.cmbTKNHBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTKNHBan.FormattingEnabled = true;
            this.cmbTKNHBan.Location = new System.Drawing.Point(179, 18);
            this.cmbTKNHBan.Name = "cmbTKNHBan";
            this.cmbTKNHBan.Size = new System.Drawing.Size(121, 21);
            this.cmbTKNHBan.TabIndex = 1;
            this.cmbTKNHBan.SelectedIndexChanged += new System.EventHandler(this.cmbTKNHBan_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(30, 21);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(111, 13);
            this.label30.TabIndex = 0;
            this.label30.Text = "Tài khoản ngân hàng:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rbLenhMPBan);
            this.groupBox7.Controls.Add(this.rbLenhLOBan);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Location = new System.Drawing.Point(18, 145);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(827, 67);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            // 
            // rbLenhMPBan
            // 
            this.rbLenhMPBan.AutoSize = true;
            this.rbLenhMPBan.Location = new System.Drawing.Point(145, 43);
            this.rbLenhMPBan.Name = "rbLenhMPBan";
            this.rbLenhMPBan.Size = new System.Drawing.Size(124, 17);
            this.rbLenhMPBan.TabIndex = 2;
            this.rbLenhMPBan.TabStop = true;
            this.rbLenhMPBan.Text = "Lệnh thị trường (MP)";
            this.rbLenhMPBan.UseVisualStyleBackColor = true;
            // 
            // rbLenhLOBan
            // 
            this.rbLenhLOBan.AutoSize = true;
            this.rbLenhLOBan.Location = new System.Drawing.Point(145, 20);
            this.rbLenhLOBan.Name = "rbLenhLOBan";
            this.rbLenhLOBan.Size = new System.Drawing.Size(131, 17);
            this.rbLenhLOBan.TabIndex = 1;
            this.rbLenhLOBan.TabStop = true;
            this.rbLenhLOBan.Text = "Lệnh đặt giới hạn (LO)";
            this.rbLenhLOBan.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(27, 29);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(53, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Loại lệnh:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cmbNgayCPBan);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.txtTenCPBan);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Controls.Add(this.cmbMaCPBan);
            this.groupBox8.Controls.Add(this.txtGiaSanBan);
            this.groupBox8.Controls.Add(this.txtGiaTranBan);
            this.groupBox8.Controls.Add(this.txtSoDuBan);
            this.groupBox8.Controls.Add(this.txtGiaThamChieuBan);
            this.groupBox8.Controls.Add(this.txtMaSGDBan);
            this.groupBox8.Controls.Add(this.label40);
            this.groupBox8.Controls.Add(this.label41);
            this.groupBox8.Controls.Add(this.label42);
            this.groupBox8.Controls.Add(this.label43);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Location = new System.Drawing.Point(18, 19);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(827, 119);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            // 
            // cmbNgayCPBan
            // 
            this.cmbNgayCPBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNgayCPBan.FormattingEnabled = true;
            this.cmbNgayCPBan.Location = new System.Drawing.Point(630, 54);
            this.cmbNgayCPBan.Name = "cmbNgayCPBan";
            this.cmbNgayCPBan.Size = new System.Drawing.Size(158, 21);
            this.cmbNgayCPBan.TabIndex = 15;
            this.cmbNgayCPBan.SelectedIndexChanged += new System.EventHandler(this.cmbNgayCPBan_SelectedIndexChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(526, 57);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(96, 13);
            this.label35.TabIndex = 3;
            this.label35.Text = "Ngày giờ cổ phiếu:";
            // 
            // txtTenCPBan
            // 
            this.txtTenCPBan.Location = new System.Drawing.Point(424, 90);
            this.txtTenCPBan.Name = "txtTenCPBan";
            this.txtTenCPBan.Size = new System.Drawing.Size(279, 21);
            this.txtTenCPBan.TabIndex = 14;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(320, 93);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(72, 13);
            this.label36.TabIndex = 13;
            this.label36.Text = "Tên cổ phiếu:";
            // 
            // cmbMaCPBan
            // 
            this.cmbMaCPBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaCPBan.FormattingEnabled = true;
            this.cmbMaCPBan.Location = new System.Drawing.Point(393, 18);
            this.cmbMaCPBan.Name = "cmbMaCPBan";
            this.cmbMaCPBan.Size = new System.Drawing.Size(100, 21);
            this.cmbMaCPBan.TabIndex = 12;
            this.cmbMaCPBan.SelectedIndexChanged += new System.EventHandler(this.cmbMaCPBan_SelectedIndexChanged);
            // 
            // txtGiaSanBan
            // 
            this.txtGiaSanBan.Location = new System.Drawing.Point(393, 54);
            this.txtGiaSanBan.Name = "txtGiaSanBan";
            this.txtGiaSanBan.Size = new System.Drawing.Size(100, 21);
            this.txtGiaSanBan.TabIndex = 11;
            // 
            // txtGiaTranBan
            // 
            this.txtGiaTranBan.Location = new System.Drawing.Point(599, 18);
            this.txtGiaTranBan.Name = "txtGiaTranBan";
            this.txtGiaTranBan.Size = new System.Drawing.Size(100, 21);
            this.txtGiaTranBan.TabIndex = 10;
            // 
            // txtSoDuBan
            // 
            this.txtSoDuBan.Location = new System.Drawing.Point(179, 90);
            this.txtSoDuBan.Name = "txtSoDuBan";
            this.txtSoDuBan.Size = new System.Drawing.Size(100, 21);
            this.txtSoDuBan.TabIndex = 8;
            // 
            // txtGiaThamChieuBan
            // 
            this.txtGiaThamChieuBan.Location = new System.Drawing.Point(179, 54);
            this.txtGiaThamChieuBan.Name = "txtGiaThamChieuBan";
            this.txtGiaThamChieuBan.Size = new System.Drawing.Size(100, 21);
            this.txtGiaThamChieuBan.TabIndex = 7;
            // 
            // txtMaSGDBan
            // 
            this.txtMaSGDBan.Location = new System.Drawing.Point(179, 18);
            this.txtMaSGDBan.Name = "txtMaSGDBan";
            this.txtMaSGDBan.Size = new System.Drawing.Size(100, 21);
            this.txtMaSGDBan.TabIndex = 6;
            this.txtMaSGDBan.Text = "HNX";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(320, 57);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(46, 13);
            this.label40.TabIndex = 5;
            this.label40.Text = "Giá sàn:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(526, 21);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(49, 13);
            this.label41.TabIndex = 4;
            this.label41.Text = "Giá trần:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(320, 21);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(68, 13);
            this.label42.TabIndex = 3;
            this.label42.Text = "Mã cổ phiếu:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(27, 93);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(138, 13);
            this.label43.TabIndex = 2;
            this.label43.Text = "Số dư được phép giao dịch:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(27, 57);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(81, 13);
            this.label44.TabIndex = 1;
            this.label44.Text = "Giá tham chiếu:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(27, 21);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(90, 13);
            this.label45.TabIndex = 0;
            this.label45.Text = "Mã sàn giao dịch:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.txtTenCPBC);
            this.tabPage4.Controls.Add(this.label50);
            this.tabPage4.Controls.Add(this.btnBaoCaoChiTiet);
            this.tabPage4.Controls.Add(this.btnBaoCaoSaoKe);
            this.tabPage4.Controls.Add(this.cmbMaCPBC);
            this.tabPage4.Controls.Add(this.label49);
            this.tabPage4.Controls.Add(this.dtpTuNgay);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.dtpDenNgay);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(861, 533);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Báo cáo";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // txtTenCPBC
            // 
            this.txtTenCPBC.Location = new System.Drawing.Point(534, 90);
            this.txtTenCPBC.Name = "txtTenCPBC";
            this.txtTenCPBC.Size = new System.Drawing.Size(279, 21);
            this.txtTenCPBC.TabIndex = 26;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(430, 93);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(72, 13);
            this.label50.TabIndex = 25;
            this.label50.Text = "Tên cổ phiếu:";
            // 
            // btnBaoCaoChiTiet
            // 
            this.btnBaoCaoChiTiet.Location = new System.Drawing.Point(543, 214);
            this.btnBaoCaoChiTiet.Name = "btnBaoCaoChiTiet";
            this.btnBaoCaoChiTiet.Size = new System.Drawing.Size(145, 23);
            this.btnBaoCaoChiTiet.TabIndex = 24;
            this.btnBaoCaoChiTiet.Text = "Báo cáo chi tiết khớp lệnh";
            this.btnBaoCaoChiTiet.UseVisualStyleBackColor = true;
            this.btnBaoCaoChiTiet.Click += new System.EventHandler(this.btnBaoCaoChiTiet_Click);
            // 
            // btnBaoCaoSaoKe
            // 
            this.btnBaoCaoSaoKe.Location = new System.Drawing.Point(30, 214);
            this.btnBaoCaoSaoKe.Name = "btnBaoCaoSaoKe";
            this.btnBaoCaoSaoKe.Size = new System.Drawing.Size(138, 23);
            this.btnBaoCaoSaoKe.TabIndex = 23;
            this.btnBaoCaoSaoKe.Text = "Báo cáo sao kê khớp lệnh";
            this.btnBaoCaoSaoKe.UseVisualStyleBackColor = true;
            this.btnBaoCaoSaoKe.Click += new System.EventHandler(this.btnBaoCaoSaoKe_Click);
            // 
            // cmbMaCPBC
            // 
            this.cmbMaCPBC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaCPBC.FormattingEnabled = true;
            this.cmbMaCPBC.Location = new System.Drawing.Point(534, 36);
            this.cmbMaCPBC.Name = "cmbMaCPBC";
            this.cmbMaCPBC.Size = new System.Drawing.Size(100, 21);
            this.cmbMaCPBC.TabIndex = 22;
            this.cmbMaCPBC.SelectedIndexChanged += new System.EventHandler(this.cmbMaCPBC_SelectedIndexChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(430, 39);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(68, 13);
            this.label49.TabIndex = 21;
            this.label49.Text = "Mã cổ phiếu:";
            // 
            // dtpTuNgay
            // 
            this.dtpTuNgay.CustomFormat = "yyyy-MM-dd";
            this.dtpTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTuNgay.Location = new System.Drawing.Point(126, 34);
            this.dtpTuNgay.Name = "dtpTuNgay";
            this.dtpTuNgay.Size = new System.Drawing.Size(134, 21);
            this.dtpTuNgay.TabIndex = 20;
            this.dtpTuNgay.Value = new System.DateTime(2020, 11, 13, 0, 0, 0, 0);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 39);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "Từ ngày:";
            // 
            // dtpDenNgay
            // 
            this.dtpDenNgay.CustomFormat = "yyyy-MM-dd";
            this.dtpDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDenNgay.Location = new System.Drawing.Point(126, 88);
            this.dtpDenNgay.Name = "dtpDenNgay";
            this.dtpDenNgay.Size = new System.Drawing.Size(134, 21);
            this.dtpDenNgay.TabIndex = 18;
            this.dtpDenNgay.Value = new System.DateTime(2020, 11, 13, 0, 0, 0, 0);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "Đến ngày:";
            // 
            // FormNhaDauTu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 664);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormNhaDauTu";
            this.Text = "FormNhaDauTu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormNhaDauTu_FormClosing);
            this.Load += new System.EventHandler(this.FormNhaDauTu_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTraCuu)).EndInit();
            this.gbTraCuu.ResumeLayout(false);
            this.gbTraCuu.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LBCongty;
        private System.Windows.Forms.Label LBQuyen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LBTen;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LBMa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnXemBaoCao;
        private System.Windows.Forms.Button btnThoatNDT;
        private System.Windows.Forms.DataGridView dgvTraCuu;
        private System.Windows.Forms.GroupBox gbTraCuu;
        private System.Windows.Forms.TextBox txtTenNDTSD;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnThoatDLM;
        private System.Windows.Forms.Button btnDL;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtMKDL;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.TextBox txtPhiGD;
        private System.Windows.Forms.TextBox txtGiaDat;
        private System.Windows.Forms.TextBox txtSoLuongDat;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cmbTKNH;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.RadioButton rbLenhMP;
        private System.Windows.Forms.RadioButton rbLenhLO;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbNgayCP;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtTenCP;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cmbMaCP;
        private System.Windows.Forms.TextBox txtGiaSan;
        private System.Windows.Forms.TextBox txtGiaTran;
        private System.Windows.Forms.TextBox txtSoDu;
        private System.Windows.Forms.TextBox txtGiaThamChieu;
        private System.Windows.Forms.TextBox txtMaSGD;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TextBox txtMaDL;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtMaCTCK;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtTenLGD;
        private System.Windows.Forms.TextBox txtDLMua;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnThoatBan;
        private System.Windows.Forms.Button btnDLBan;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtDLBan;
        private System.Windows.Forms.TextBox txtMaCTCKBan;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtTenLGDBan;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtMKDLBan;
        private System.Windows.Forms.TextBox txtTongTienBan;
        private System.Windows.Forms.TextBox txtPhiGDBan;
        private System.Windows.Forms.TextBox txtGiaDatBan;
        private System.Windows.Forms.TextBox txtSoLuongDatBan;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtMaDLBan;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox cmbTKNHBan;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rbLenhMPBan;
        private System.Windows.Forms.RadioButton rbLenhLOBan;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox cmbNgayCPBan;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtTenCPBan;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cmbMaCPBan;
        private System.Windows.Forms.TextBox txtGiaSanBan;
        private System.Windows.Forms.TextBox txtGiaTranBan;
        private System.Windows.Forms.TextBox txtSoDuBan;
        private System.Windows.Forms.TextBox txtGiaThamChieuBan;
        private System.Windows.Forms.TextBox txtMaSGDBan;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button btnThanhTien;
        private System.Windows.Forms.Button btnThanhtienBan;
        private System.Windows.Forms.TextBox txtTenNHSD;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox cmbMaNH;
        private System.Windows.Forms.TextBox txtSoduGD;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtMaTKNHSD;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DateTimePicker dtpTuNgay;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtpDenNgay;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnBaoCaoChiTiet;
        private System.Windows.Forms.Button btnBaoCaoSaoKe;
        private System.Windows.Forms.ComboBox cmbMaCPBC;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLD;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayGio;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTKNH;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaoDich;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongKhop;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaKhop;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenTT;
        private System.Windows.Forms.TextBox txtTenCPBC;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.DateTimePicker dtpNgayDat;
        private System.Windows.Forms.DateTimePicker dtpNgayDatBan;
    }
}