﻿namespace QLGDCK
{
    partial class FormCongTy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.MaNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhaiNV = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.NgaySinhNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChiNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoDTNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DaNghiViec = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gbNhanVien = new System.Windows.Forms.GroupBox();
            this.nghiCheckEdit = new DevExpress.XtraEditors.CheckEdit();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.phaiCheckedit = new DevExpress.XtraEditors.CheckEdit();
            this.btnHuy = new System.Windows.Forms.Button();
            this.txtDiachiNV = new System.Windows.Forms.TextBox();
            this.btnGhi = new System.Windows.Forms.Button();
            this.dtpNgaysinhNV = new System.Windows.Forms.DateTimePicker();
            this.txtTenNV = new System.Windows.Forms.TextBox();
            this.txtHoNV = new System.Windows.Forms.TextBox();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnThoatNV = new System.Windows.Forms.Button();
            this.btnLamMoiNV = new System.Windows.Forms.Button();
            this.btnUndoNV = new System.Windows.Forms.Button();
            this.btnSuaNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvNhaDauTu = new System.Windows.Forms.DataGridView();
            this.MaTK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoNDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenNDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhaiNDT = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DiaChiNDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoDTNDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CMND = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Passport = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgaySinhNDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayCap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuocGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MKGiaoDich = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MKDatLenh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbNhaDauTu = new System.Windows.Forms.GroupBox();
            this.dtpNgayCap = new System.Windows.Forms.DateTimePicker();
            this.dtpNgaysinhNDT = new System.Windows.Forms.DateTimePicker();
            this.phaicheckEditNDT = new DevExpress.XtraEditors.CheckEdit();
            this.txtMKDL = new System.Windows.Forms.TextBox();
            this.txtMKGD = new System.Windows.Forms.TextBox();
            this.txtQuocgia = new System.Windows.Forms.TextBox();
            this.txtPassport = new System.Windows.Forms.TextBox();
            this.txtCMND = new System.Windows.Forms.TextBox();
            this.btnGhiNDT = new System.Windows.Forms.Button();
            this.txtSDTNDT = new System.Windows.Forms.TextBox();
            this.btnHuyNDT = new System.Windows.Forms.Button();
            this.txtDiachiNDT = new System.Windows.Forms.TextBox();
            this.txtEmailNDT = new System.Windows.Forms.TextBox();
            this.txtTenNDT = new System.Windows.Forms.TextBox();
            this.txtHoNDT = new System.Windows.Forms.TextBox();
            this.txtMaNDT = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnThoatNDT = new System.Windows.Forms.Button();
            this.btnRefreshNDT = new System.Windows.Forms.Button();
            this.btnUndoNDT = new System.Windows.Forms.Button();
            this.btnSuaNDT = new System.Windows.Forms.Button();
            this.btnXoaNDT = new System.Windows.Forms.Button();
            this.btnThemNDT = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvTKNH = new System.Windows.Forms.DataGridView();
            this.MaTKNH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaNH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoDuTKNH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaTKSD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbTKNH = new System.Windows.Forms.GroupBox();
            this.btnHuyTKNH = new System.Windows.Forms.Button();
            this.btnGhiTKNH = new System.Windows.Forms.Button();
            this.cmbNDTNH = new System.Windows.Forms.ComboBox();
            this.cmbNH = new System.Windows.Forms.ComboBox();
            this.txtTenNH = new System.Windows.Forms.TextBox();
            this.txtSodu = new System.Windows.Forms.TextBox();
            this.txtMaTKNH = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.btnThoatTKNH = new System.Windows.Forms.Button();
            this.btnRefreshTKNH = new System.Windows.Forms.Button();
            this.btnUndoTKNH = new System.Windows.Forms.Button();
            this.btnSuaTKNH = new System.Windows.Forms.Button();
            this.btnXoaTKNH = new System.Windows.Forms.Button();
            this.btnThemTKNH = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgvPGD = new System.Windows.Forms.DataGridView();
            this.MaLGD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayGio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaPhi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbPGD = new System.Windows.Forms.GroupBox();
            this.btnHuyPGD = new System.Windows.Forms.Button();
            this.btnGhiPGD = new System.Windows.Forms.Button();
            this.cmbMaLGD = new System.Windows.Forms.ComboBox();
            this.dtpPGD = new System.Windows.Forms.DateTimePicker();
            this.txtGiaPhi = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.btnThoatPGD = new System.Windows.Forms.Button();
            this.btnRefreshPGD = new System.Windows.Forms.Button();
            this.btnUndoPGD = new System.Windows.Forms.Button();
            this.btnSuaPGD = new System.Windows.Forms.Button();
            this.btnThemPGD = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dgvTraCuuCP = new System.Windows.Forms.DataGridView();
            this.MaLD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaoDich = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongDat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaDat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongKhop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaKhop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTenNHSD = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cmbMaNH = new System.Windows.Forms.ComboBox();
            this.txtSoduGD = new System.Windows.Forms.TextBox();
            this.txtMaTKNHSD = new System.Windows.Forms.TextBox();
            this.txtTenNDTSD = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.btnRP = new System.Windows.Forms.Button();
            this.btnThoatSD = new System.Windows.Forms.Button();
            this.cmbNDT = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.cmbMaNV = new System.Windows.Forms.ComboBox();
            this.cmbNhom = new System.Windows.Forms.ComboBox();
            this.btnThoatLG = new System.Windows.Forms.Button();
            this.btnXacNhanLG = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtTenLG = new System.Windows.Forms.TextBox();
            this.txtMKLG = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LBCongty = new System.Windows.Forms.Label();
            this.LBQuyen = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LBTen = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LBMa = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.gbNhanVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nghiCheckEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phaiCheckedit.Properties)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhaDauTu)).BeginInit();
            this.gbNhaDauTu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.phaicheckEditNDT.Properties)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKNH)).BeginInit();
            this.gbTKNH.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPGD)).BeginInit();
            this.gbPGD.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTraCuuCP)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(0, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(790, 583);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvNhanVien);
            this.tabPage1.Controls.Add(this.gbNhanVien);
            this.tabPage1.Controls.Add(this.btnThoatNV);
            this.tabPage1.Controls.Add(this.btnLamMoiNV);
            this.tabPage1.Controls.Add(this.btnUndoNV);
            this.tabPage1.Controls.Add(this.btnSuaNV);
            this.tabPage1.Controls.Add(this.btnXoaNV);
            this.tabPage1.Controls.Add(this.btnThemNV);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(782, 557);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Nhân viên";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaNV,
            this.HoNV,
            this.TenNV,
            this.PhaiNV,
            this.NgaySinhNV,
            this.DiaChiNV,
            this.SoDTNV,
            this.DaNghiViec});
            this.dgvNhanVien.Location = new System.Drawing.Point(20, 312);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.Size = new System.Drawing.Size(720, 239);
            this.dgvNhanVien.TabIndex = 7;
            this.dgvNhanVien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNhanVien_CellContentClick);
            // 
            // MaNV
            // 
            this.MaNV.DataPropertyName = "MaNV";
            this.MaNV.HeaderText = "Mã nhân viên";
            this.MaNV.Name = "MaNV";
            // 
            // HoNV
            // 
            this.HoNV.DataPropertyName = "Ho";
            this.HoNV.HeaderText = "Họ";
            this.HoNV.Name = "HoNV";
            // 
            // TenNV
            // 
            this.TenNV.DataPropertyName = "Ten";
            this.TenNV.HeaderText = "Tên";
            this.TenNV.Name = "TenNV";
            // 
            // PhaiNV
            // 
            this.PhaiNV.DataPropertyName = "Phai";
            this.PhaiNV.HeaderText = "Phái";
            this.PhaiNV.Name = "PhaiNV";
            this.PhaiNV.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.PhaiNV.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // NgaySinhNV
            // 
            this.NgaySinhNV.DataPropertyName = "NgaySinh";
            this.NgaySinhNV.HeaderText = "Ngày sinh";
            this.NgaySinhNV.Name = "NgaySinhNV";
            // 
            // DiaChiNV
            // 
            this.DiaChiNV.DataPropertyName = "DiaChi";
            this.DiaChiNV.HeaderText = "Địa chỉ";
            this.DiaChiNV.Name = "DiaChiNV";
            // 
            // SoDTNV
            // 
            this.SoDTNV.DataPropertyName = "SoDT";
            this.SoDTNV.HeaderText = "Số điện thoại";
            this.SoDTNV.Name = "SoDTNV";
            // 
            // DaNghiViec
            // 
            this.DaNghiViec.DataPropertyName = "DaNghiViec";
            this.DaNghiViec.HeaderText = "Đã nghỉ việc";
            this.DaNghiViec.Name = "DaNghiViec";
            this.DaNghiViec.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DaNghiViec.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // gbNhanVien
            // 
            this.gbNhanVien.Controls.Add(this.nghiCheckEdit);
            this.gbNhanVien.Controls.Add(this.txtSDT);
            this.gbNhanVien.Controls.Add(this.phaiCheckedit);
            this.gbNhanVien.Controls.Add(this.btnHuy);
            this.gbNhanVien.Controls.Add(this.txtDiachiNV);
            this.gbNhanVien.Controls.Add(this.btnGhi);
            this.gbNhanVien.Controls.Add(this.dtpNgaysinhNV);
            this.gbNhanVien.Controls.Add(this.txtTenNV);
            this.gbNhanVien.Controls.Add(this.txtHoNV);
            this.gbNhanVien.Controls.Add(this.txtMaNV);
            this.gbNhanVien.Controls.Add(this.label11);
            this.gbNhanVien.Controls.Add(this.label10);
            this.gbNhanVien.Controls.Add(this.label9);
            this.gbNhanVien.Controls.Add(this.label8);
            this.gbNhanVien.Controls.Add(this.label7);
            this.gbNhanVien.Controls.Add(this.label6);
            this.gbNhanVien.Controls.Add(this.label4);
            this.gbNhanVien.Controls.Add(this.label2);
            this.gbNhanVien.Location = new System.Drawing.Point(20, 75);
            this.gbNhanVien.Name = "gbNhanVien";
            this.gbNhanVien.Size = new System.Drawing.Size(720, 231);
            this.gbNhanVien.TabIndex = 6;
            this.gbNhanVien.TabStop = false;
            // 
            // nghiCheckEdit
            // 
            this.nghiCheckEdit.Location = new System.Drawing.Point(627, 84);
            this.nghiCheckEdit.Name = "nghiCheckEdit";
            this.nghiCheckEdit.Properties.Caption = "Nghỉ";
            this.nghiCheckEdit.Size = new System.Drawing.Size(75, 20);
            this.nghiCheckEdit.TabIndex = 21;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(592, 30);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(100, 21);
            this.txtSDT.TabIndex = 20;
            // 
            // phaiCheckedit
            // 
            this.phaiCheckedit.Location = new System.Drawing.Point(308, 30);
            this.phaiCheckedit.Name = "phaiCheckedit";
            this.phaiCheckedit.Properties.Caption = "Nam";
            this.phaiCheckedit.Size = new System.Drawing.Size(75, 20);
            this.phaiCheckedit.TabIndex = 19;
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(421, 189);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(75, 23);
            this.btnHuy.TabIndex = 18;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // txtDiachiNV
            // 
            this.txtDiachiNV.Location = new System.Drawing.Point(335, 146);
            this.txtDiachiNV.Name = "txtDiachiNV";
            this.txtDiachiNV.Size = new System.Drawing.Size(367, 21);
            this.txtDiachiNV.TabIndex = 16;
            // 
            // btnGhi
            // 
            this.btnGhi.Location = new System.Drawing.Point(195, 189);
            this.btnGhi.Name = "btnGhi";
            this.btnGhi.Size = new System.Drawing.Size(75, 23);
            this.btnGhi.TabIndex = 17;
            this.btnGhi.Text = "Ghi";
            this.btnGhi.UseVisualStyleBackColor = true;
            this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
            // 
            // dtpNgaysinhNV
            // 
            this.dtpNgaysinhNV.Location = new System.Drawing.Point(335, 81);
            this.dtpNgaysinhNV.Name = "dtpNgaysinhNV";
            this.dtpNgaysinhNV.Size = new System.Drawing.Size(200, 21);
            this.dtpNgaysinhNV.TabIndex = 14;
            // 
            // txtTenNV
            // 
            this.txtTenNV.Location = new System.Drawing.Point(97, 146);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Size = new System.Drawing.Size(100, 21);
            this.txtTenNV.TabIndex = 11;
            // 
            // txtHoNV
            // 
            this.txtHoNV.Location = new System.Drawing.Point(97, 84);
            this.txtHoNV.Name = "txtHoNV";
            this.txtHoNV.Size = new System.Drawing.Size(100, 21);
            this.txtHoNV.TabIndex = 10;
            // 
            // txtMaNV
            // 
            this.txtMaNV.Location = new System.Drawing.Point(97, 30);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(100, 21);
            this.txtMaNV.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(554, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Đã nghỉ việc:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(501, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Số điện thoại:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(271, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Địa chỉ:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(271, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Ngày sinh:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(271, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Phái:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Tên:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Họ:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã nhân viên:";
            // 
            // btnThoatNV
            // 
            this.btnThoatNV.Location = new System.Drawing.Point(665, 30);
            this.btnThoatNV.Name = "btnThoatNV";
            this.btnThoatNV.Size = new System.Drawing.Size(75, 23);
            this.btnThoatNV.TabIndex = 5;
            this.btnThoatNV.Text = "Thoát";
            this.btnThoatNV.UseVisualStyleBackColor = true;
            this.btnThoatNV.Click += new System.EventHandler(this.btnThoatNV_Click);
            // 
            // btnLamMoiNV
            // 
            this.btnLamMoiNV.Location = new System.Drawing.Point(534, 30);
            this.btnLamMoiNV.Name = "btnLamMoiNV";
            this.btnLamMoiNV.Size = new System.Drawing.Size(75, 23);
            this.btnLamMoiNV.TabIndex = 4;
            this.btnLamMoiNV.Text = "Refresh";
            this.btnLamMoiNV.UseVisualStyleBackColor = true;
            this.btnLamMoiNV.Click += new System.EventHandler(this.btnLamMoiNV_Click);
            // 
            // btnUndoNV
            // 
            this.btnUndoNV.Location = new System.Drawing.Point(408, 30);
            this.btnUndoNV.Name = "btnUndoNV";
            this.btnUndoNV.Size = new System.Drawing.Size(75, 23);
            this.btnUndoNV.TabIndex = 3;
            this.btnUndoNV.Text = "Undo";
            this.btnUndoNV.UseVisualStyleBackColor = true;
            this.btnUndoNV.Click += new System.EventHandler(this.btnUndoNV_Click);
            // 
            // btnSuaNV
            // 
            this.btnSuaNV.Location = new System.Drawing.Point(276, 30);
            this.btnSuaNV.Name = "btnSuaNV";
            this.btnSuaNV.Size = new System.Drawing.Size(75, 23);
            this.btnSuaNV.TabIndex = 2;
            this.btnSuaNV.Text = "Sửa";
            this.btnSuaNV.UseVisualStyleBackColor = true;
            this.btnSuaNV.Click += new System.EventHandler(this.btnSuaNV_Click);
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Location = new System.Drawing.Point(142, 30);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(75, 23);
            this.btnXoaNV.TabIndex = 1;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // btnThemNV
            // 
            this.btnThemNV.Location = new System.Drawing.Point(20, 30);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(75, 23);
            this.btnThemNV.TabIndex = 0;
            this.btnThemNV.Text = "Thêm";
            this.btnThemNV.UseVisualStyleBackColor = true;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgvNhaDauTu);
            this.tabPage2.Controls.Add(this.gbNhaDauTu);
            this.tabPage2.Controls.Add(this.btnThoatNDT);
            this.tabPage2.Controls.Add(this.btnRefreshNDT);
            this.tabPage2.Controls.Add(this.btnUndoNDT);
            this.tabPage2.Controls.Add(this.btnSuaNDT);
            this.tabPage2.Controls.Add(this.btnXoaNDT);
            this.tabPage2.Controls.Add(this.btnThemNDT);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(782, 557);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Nhà đầu tư";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgvNhaDauTu
            // 
            this.dgvNhaDauTu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhaDauTu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaTK,
            this.HoNDT,
            this.TenNDT,
            this.PhaiNDT,
            this.DiaChiNDT,
            this.SoDTNDT,
            this.Email,
            this.CMND,
            this.Passport,
            this.NgaySinhNDT,
            this.NgayCap,
            this.QuocGia,
            this.MKGiaoDich,
            this.MKDatLenh});
            this.dgvNhaDauTu.Location = new System.Drawing.Point(24, 395);
            this.dgvNhaDauTu.Name = "dgvNhaDauTu";
            this.dgvNhaDauTu.Size = new System.Drawing.Size(733, 159);
            this.dgvNhaDauTu.TabIndex = 13;
            this.dgvNhaDauTu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNhaDauTu_CellContentClick);
            // 
            // MaTK
            // 
            this.MaTK.DataPropertyName = "MaTK";
            this.MaTK.HeaderText = "Mã nhà đầu tư";
            this.MaTK.MinimumWidth = 6;
            this.MaTK.Name = "MaTK";
            this.MaTK.Width = 125;
            // 
            // HoNDT
            // 
            this.HoNDT.DataPropertyName = "Ho";
            this.HoNDT.HeaderText = "Họ";
            this.HoNDT.Name = "HoNDT";
            // 
            // TenNDT
            // 
            this.TenNDT.DataPropertyName = "Ten";
            this.TenNDT.HeaderText = "Tên";
            this.TenNDT.Name = "TenNDT";
            // 
            // PhaiNDT
            // 
            this.PhaiNDT.DataPropertyName = "Phai";
            this.PhaiNDT.HeaderText = "Phái";
            this.PhaiNDT.Name = "PhaiNDT";
            // 
            // DiaChiNDT
            // 
            this.DiaChiNDT.DataPropertyName = "DiaChi";
            this.DiaChiNDT.HeaderText = "Địa Chỉ";
            this.DiaChiNDT.Name = "DiaChiNDT";
            // 
            // SoDTNDT
            // 
            this.SoDTNDT.DataPropertyName = "SoDT";
            this.SoDTNDT.HeaderText = "Số điện thoại";
            this.SoDTNDT.Name = "SoDTNDT";
            // 
            // Email
            // 
            this.Email.DataPropertyName = "Email";
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            // 
            // CMND
            // 
            this.CMND.DataPropertyName = "CMND";
            this.CMND.HeaderText = "CMND";
            this.CMND.Name = "CMND";
            // 
            // Passport
            // 
            this.Passport.DataPropertyName = "Passport";
            this.Passport.HeaderText = "Passport";
            this.Passport.Name = "Passport";
            // 
            // NgaySinhNDT
            // 
            this.NgaySinhNDT.DataPropertyName = "NgaySinh";
            this.NgaySinhNDT.HeaderText = "Ngày sinh";
            this.NgaySinhNDT.Name = "NgaySinhNDT";
            // 
            // NgayCap
            // 
            this.NgayCap.DataPropertyName = "NgayCap";
            this.NgayCap.HeaderText = "Ngày cấp";
            this.NgayCap.Name = "NgayCap";
            // 
            // QuocGia
            // 
            this.QuocGia.DataPropertyName = "QuocGia";
            this.QuocGia.HeaderText = "Quốc gia";
            this.QuocGia.Name = "QuocGia";
            // 
            // MKGiaoDich
            // 
            this.MKGiaoDich.DataPropertyName = "MKGiaoDich";
            this.MKGiaoDich.HeaderText = "Mật khẩu giao dịch";
            this.MKGiaoDich.Name = "MKGiaoDich";
            // 
            // MKDatLenh
            // 
            this.MKDatLenh.DataPropertyName = "MKDatLenh";
            this.MKDatLenh.HeaderText = "Mật khẩu đặt lệnh";
            this.MKDatLenh.Name = "MKDatLenh";
            // 
            // gbNhaDauTu
            // 
            this.gbNhaDauTu.Controls.Add(this.dtpNgayCap);
            this.gbNhaDauTu.Controls.Add(this.dtpNgaysinhNDT);
            this.gbNhaDauTu.Controls.Add(this.phaicheckEditNDT);
            this.gbNhaDauTu.Controls.Add(this.txtMKDL);
            this.gbNhaDauTu.Controls.Add(this.txtMKGD);
            this.gbNhaDauTu.Controls.Add(this.txtQuocgia);
            this.gbNhaDauTu.Controls.Add(this.txtPassport);
            this.gbNhaDauTu.Controls.Add(this.txtCMND);
            this.gbNhaDauTu.Controls.Add(this.btnGhiNDT);
            this.gbNhaDauTu.Controls.Add(this.txtSDTNDT);
            this.gbNhaDauTu.Controls.Add(this.btnHuyNDT);
            this.gbNhaDauTu.Controls.Add(this.txtDiachiNDT);
            this.gbNhaDauTu.Controls.Add(this.txtEmailNDT);
            this.gbNhaDauTu.Controls.Add(this.txtTenNDT);
            this.gbNhaDauTu.Controls.Add(this.txtHoNDT);
            this.gbNhaDauTu.Controls.Add(this.txtMaNDT);
            this.gbNhaDauTu.Controls.Add(this.label25);
            this.gbNhaDauTu.Controls.Add(this.label24);
            this.gbNhaDauTu.Controls.Add(this.label23);
            this.gbNhaDauTu.Controls.Add(this.label22);
            this.gbNhaDauTu.Controls.Add(this.label21);
            this.gbNhaDauTu.Controls.Add(this.label20);
            this.gbNhaDauTu.Controls.Add(this.label19);
            this.gbNhaDauTu.Controls.Add(this.label18);
            this.gbNhaDauTu.Controls.Add(this.label17);
            this.gbNhaDauTu.Controls.Add(this.label16);
            this.gbNhaDauTu.Controls.Add(this.label15);
            this.gbNhaDauTu.Controls.Add(this.label14);
            this.gbNhaDauTu.Controls.Add(this.label13);
            this.gbNhaDauTu.Controls.Add(this.label12);
            this.gbNhaDauTu.Location = new System.Drawing.Point(24, 61);
            this.gbNhaDauTu.Name = "gbNhaDauTu";
            this.gbNhaDauTu.Size = new System.Drawing.Size(733, 328);
            this.gbNhaDauTu.TabIndex = 12;
            this.gbNhaDauTu.TabStop = false;
            // 
            // dtpNgayCap
            // 
            this.dtpNgayCap.Location = new System.Drawing.Point(514, 48);
            this.dtpNgayCap.Name = "dtpNgayCap";
            this.dtpNgayCap.Size = new System.Drawing.Size(200, 21);
            this.dtpNgayCap.TabIndex = 29;
            // 
            // dtpNgaysinhNDT
            // 
            this.dtpNgaysinhNDT.Location = new System.Drawing.Point(105, 260);
            this.dtpNgaysinhNDT.Name = "dtpNgaysinhNDT";
            this.dtpNgaysinhNDT.Size = new System.Drawing.Size(201, 21);
            this.dtpNgaysinhNDT.TabIndex = 28;
            // 
            // phaicheckEditNDT
            // 
            this.phaicheckEditNDT.Location = new System.Drawing.Point(342, 51);
            this.phaicheckEditNDT.Name = "phaicheckEditNDT";
            this.phaicheckEditNDT.Properties.Caption = "Nam";
            this.phaicheckEditNDT.Size = new System.Drawing.Size(75, 20);
            this.phaicheckEditNDT.TabIndex = 27;
            // 
            // txtMKDL
            // 
            this.txtMKDL.Location = new System.Drawing.Point(589, 203);
            this.txtMKDL.Name = "txtMKDL";
            this.txtMKDL.PasswordChar = '*';
            this.txtMKDL.Size = new System.Drawing.Size(100, 21);
            this.txtMKDL.TabIndex = 26;
            // 
            // txtMKGD
            // 
            this.txtMKGD.Location = new System.Drawing.Point(589, 151);
            this.txtMKGD.Name = "txtMKGD";
            this.txtMKGD.PasswordChar = '*';
            this.txtMKGD.Size = new System.Drawing.Size(100, 21);
            this.txtMKGD.TabIndex = 25;
            // 
            // txtQuocgia
            // 
            this.txtQuocgia.Location = new System.Drawing.Point(589, 97);
            this.txtQuocgia.Name = "txtQuocgia";
            this.txtQuocgia.Size = new System.Drawing.Size(100, 21);
            this.txtQuocgia.TabIndex = 24;
            // 
            // txtPassport
            // 
            this.txtPassport.Location = new System.Drawing.Point(342, 203);
            this.txtPassport.Name = "txtPassport";
            this.txtPassport.Size = new System.Drawing.Size(100, 21);
            this.txtPassport.TabIndex = 23;
            // 
            // txtCMND
            // 
            this.txtCMND.Location = new System.Drawing.Point(342, 151);
            this.txtCMND.Name = "txtCMND";
            this.txtCMND.Size = new System.Drawing.Size(100, 21);
            this.txtCMND.TabIndex = 22;
            // 
            // btnGhiNDT
            // 
            this.btnGhiNDT.Location = new System.Drawing.Point(163, 290);
            this.btnGhiNDT.Name = "btnGhiNDT";
            this.btnGhiNDT.Size = new System.Drawing.Size(75, 23);
            this.btnGhiNDT.TabIndex = 14;
            this.btnGhiNDT.Text = "Ghi";
            this.btnGhiNDT.UseVisualStyleBackColor = true;
            this.btnGhiNDT.Click += new System.EventHandler(this.btnGhiNDT_Click);
            // 
            // txtSDTNDT
            // 
            this.txtSDTNDT.Location = new System.Drawing.Point(342, 97);
            this.txtSDTNDT.Name = "txtSDTNDT";
            this.txtSDTNDT.Size = new System.Drawing.Size(100, 21);
            this.txtSDTNDT.TabIndex = 21;
            // 
            // btnHuyNDT
            // 
            this.btnHuyNDT.Location = new System.Drawing.Point(432, 290);
            this.btnHuyNDT.Name = "btnHuyNDT";
            this.btnHuyNDT.Size = new System.Drawing.Size(75, 23);
            this.btnHuyNDT.TabIndex = 15;
            this.btnHuyNDT.Text = "Hủy";
            this.btnHuyNDT.UseVisualStyleBackColor = true;
            this.btnHuyNDT.Click += new System.EventHandler(this.btnHuyNDT_Click);
            // 
            // txtDiachiNDT
            // 
            this.txtDiachiNDT.Location = new System.Drawing.Point(432, 263);
            this.txtDiachiNDT.Name = "txtDiachiNDT";
            this.txtDiachiNDT.Size = new System.Drawing.Size(210, 21);
            this.txtDiachiNDT.TabIndex = 20;
            // 
            // txtEmailNDT
            // 
            this.txtEmailNDT.Location = new System.Drawing.Point(97, 203);
            this.txtEmailNDT.Name = "txtEmailNDT";
            this.txtEmailNDT.Size = new System.Drawing.Size(141, 21);
            this.txtEmailNDT.TabIndex = 19;
            // 
            // txtTenNDT
            // 
            this.txtTenNDT.Location = new System.Drawing.Point(97, 151);
            this.txtTenNDT.Name = "txtTenNDT";
            this.txtTenNDT.Size = new System.Drawing.Size(100, 21);
            this.txtTenNDT.TabIndex = 18;
            // 
            // txtHoNDT
            // 
            this.txtHoNDT.Location = new System.Drawing.Point(97, 97);
            this.txtHoNDT.Name = "txtHoNDT";
            this.txtHoNDT.Size = new System.Drawing.Size(100, 21);
            this.txtHoNDT.TabIndex = 17;
            // 
            // txtMaNDT
            // 
            this.txtMaNDT.Location = new System.Drawing.Point(97, 51);
            this.txtMaNDT.Name = "txtMaNDT";
            this.txtMaNDT.Size = new System.Drawing.Size(100, 21);
            this.txtMaNDT.TabIndex = 16;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(479, 206);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(97, 13);
            this.label25.TabIndex = 13;
            this.label25.Text = "Mật khẩu đặt lệnh:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(479, 154);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(100, 13);
            this.label24.TabIndex = 12;
            this.label24.Text = "Mật khẩu giao dịch:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(479, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 13);
            this.label23.TabIndex = 11;
            this.label23.Text = "Quốc gia:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(448, 54);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 13);
            this.label22.TabIndex = 10;
            this.label22.Text = "Ngày cấp:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(371, 266);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 13);
            this.label21.TabIndex = 9;
            this.label21.Text = "Địa chỉ:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(253, 206);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "Passport:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(253, 154);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "CMND:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(253, 100);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(73, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Số điện thoại:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(253, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(31, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Phái:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(33, 206);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Email:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(33, 263);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Ngày sinh:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(33, 154);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Tên:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(33, 100);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Họ:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Mã đầu tư:";
            // 
            // btnThoatNDT
            // 
            this.btnThoatNDT.Location = new System.Drawing.Point(669, 17);
            this.btnThoatNDT.Name = "btnThoatNDT";
            this.btnThoatNDT.Size = new System.Drawing.Size(75, 23);
            this.btnThoatNDT.TabIndex = 11;
            this.btnThoatNDT.Text = "Thoát";
            this.btnThoatNDT.UseVisualStyleBackColor = true;
            this.btnThoatNDT.Click += new System.EventHandler(this.btnThoatNDT_Click);
            // 
            // btnRefreshNDT
            // 
            this.btnRefreshNDT.Location = new System.Drawing.Point(538, 17);
            this.btnRefreshNDT.Name = "btnRefreshNDT";
            this.btnRefreshNDT.Size = new System.Drawing.Size(75, 23);
            this.btnRefreshNDT.TabIndex = 10;
            this.btnRefreshNDT.Text = "Refresh";
            this.btnRefreshNDT.UseVisualStyleBackColor = true;
            this.btnRefreshNDT.Click += new System.EventHandler(this.btnRefreshNDT_Click);
            // 
            // btnUndoNDT
            // 
            this.btnUndoNDT.Location = new System.Drawing.Point(412, 17);
            this.btnUndoNDT.Name = "btnUndoNDT";
            this.btnUndoNDT.Size = new System.Drawing.Size(75, 23);
            this.btnUndoNDT.TabIndex = 9;
            this.btnUndoNDT.Text = "Undo";
            this.btnUndoNDT.UseVisualStyleBackColor = true;
            this.btnUndoNDT.Click += new System.EventHandler(this.btnUndoNDT_Click);
            // 
            // btnSuaNDT
            // 
            this.btnSuaNDT.Location = new System.Drawing.Point(280, 17);
            this.btnSuaNDT.Name = "btnSuaNDT";
            this.btnSuaNDT.Size = new System.Drawing.Size(75, 23);
            this.btnSuaNDT.TabIndex = 8;
            this.btnSuaNDT.Text = "Sửa";
            this.btnSuaNDT.UseVisualStyleBackColor = true;
            this.btnSuaNDT.Click += new System.EventHandler(this.btnSuaNDT_Click);
            // 
            // btnXoaNDT
            // 
            this.btnXoaNDT.Location = new System.Drawing.Point(146, 17);
            this.btnXoaNDT.Name = "btnXoaNDT";
            this.btnXoaNDT.Size = new System.Drawing.Size(75, 23);
            this.btnXoaNDT.TabIndex = 7;
            this.btnXoaNDT.Text = "Xóa";
            this.btnXoaNDT.UseVisualStyleBackColor = true;
            this.btnXoaNDT.Click += new System.EventHandler(this.btnXoaNDT_Click);
            // 
            // btnThemNDT
            // 
            this.btnThemNDT.Location = new System.Drawing.Point(24, 17);
            this.btnThemNDT.Name = "btnThemNDT";
            this.btnThemNDT.Size = new System.Drawing.Size(75, 23);
            this.btnThemNDT.TabIndex = 6;
            this.btnThemNDT.Text = "Thêm";
            this.btnThemNDT.UseVisualStyleBackColor = true;
            this.btnThemNDT.Click += new System.EventHandler(this.btnThemNDT_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgvTKNH);
            this.tabPage3.Controls.Add(this.gbTKNH);
            this.tabPage3.Controls.Add(this.btnThoatTKNH);
            this.tabPage3.Controls.Add(this.btnRefreshTKNH);
            this.tabPage3.Controls.Add(this.btnUndoTKNH);
            this.tabPage3.Controls.Add(this.btnSuaTKNH);
            this.tabPage3.Controls.Add(this.btnXoaTKNH);
            this.tabPage3.Controls.Add(this.btnThemTKNH);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(782, 557);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tài khoản ngân hàng";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgvTKNH
            // 
            this.dgvTKNH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTKNH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaTKNH,
            this.MaNH,
            this.SoDuTKNH,
            this.MaTKSD});
            this.dgvTKNH.Location = new System.Drawing.Point(29, 332);
            this.dgvTKNH.Name = "dgvTKNH";
            this.dgvTKNH.Size = new System.Drawing.Size(717, 196);
            this.dgvTKNH.TabIndex = 21;
            this.dgvTKNH.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTKNH_CellContentClick);
            // 
            // MaTKNH
            // 
            this.MaTKNH.DataPropertyName = "MaTKNH";
            this.MaTKNH.HeaderText = "Mã tài khoản";
            this.MaTKNH.Name = "MaTKNH";
            this.MaTKNH.Width = 113;
            // 
            // MaNH
            // 
            this.MaNH.DataPropertyName = "MaNH";
            this.MaNH.HeaderText = "Mã ngân hàng";
            this.MaNH.Name = "MaNH";
            // 
            // SoDuTKNH
            // 
            this.SoDuTKNH.DataPropertyName = "SoDuTKNH";
            this.SoDuTKNH.HeaderText = "Số dư tài khoản";
            this.SoDuTKNH.MinimumWidth = 6;
            this.SoDuTKNH.Name = "SoDuTKNH";
            this.SoDuTKNH.Width = 125;
            // 
            // MaTKSD
            // 
            this.MaTKSD.DataPropertyName = "MaTK";
            this.MaTKSD.HeaderText = "Mã nhà đầu tư";
            this.MaTKSD.MinimumWidth = 6;
            this.MaTKSD.Name = "MaTKSD";
            this.MaTKSD.Width = 125;
            // 
            // gbTKNH
            // 
            this.gbTKNH.Controls.Add(this.btnHuyTKNH);
            this.gbTKNH.Controls.Add(this.btnGhiTKNH);
            this.gbTKNH.Controls.Add(this.cmbNDTNH);
            this.gbTKNH.Controls.Add(this.cmbNH);
            this.gbTKNH.Controls.Add(this.txtTenNH);
            this.gbTKNH.Controls.Add(this.txtSodu);
            this.gbTKNH.Controls.Add(this.txtMaTKNH);
            this.gbTKNH.Controls.Add(this.label30);
            this.gbTKNH.Controls.Add(this.label29);
            this.gbTKNH.Controls.Add(this.label28);
            this.gbTKNH.Controls.Add(this.label27);
            this.gbTKNH.Controls.Add(this.label26);
            this.gbTKNH.Location = new System.Drawing.Point(29, 75);
            this.gbTKNH.Name = "gbTKNH";
            this.gbTKNH.Size = new System.Drawing.Size(717, 241);
            this.gbTKNH.TabIndex = 18;
            this.gbTKNH.TabStop = false;
            // 
            // btnHuyTKNH
            // 
            this.btnHuyTKNH.Location = new System.Drawing.Point(428, 193);
            this.btnHuyTKNH.Name = "btnHuyTKNH";
            this.btnHuyTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnHuyTKNH.TabIndex = 32;
            this.btnHuyTKNH.Text = "Hủy";
            this.btnHuyTKNH.UseVisualStyleBackColor = true;
            this.btnHuyTKNH.Click += new System.EventHandler(this.btnHuyTKNH_Click);
            // 
            // btnGhiTKNH
            // 
            this.btnGhiTKNH.Location = new System.Drawing.Point(209, 193);
            this.btnGhiTKNH.Name = "btnGhiTKNH";
            this.btnGhiTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnGhiTKNH.TabIndex = 31;
            this.btnGhiTKNH.Text = "Ghi";
            this.btnGhiTKNH.UseVisualStyleBackColor = true;
            this.btnGhiTKNH.Click += new System.EventHandler(this.btnGhiTKNH_Click);
            // 
            // cmbNDTNH
            // 
            this.cmbNDTNH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNDTNH.FormattingEnabled = true;
            this.cmbNDTNH.Location = new System.Drawing.Point(192, 142);
            this.cmbNDTNH.Name = "cmbNDTNH";
            this.cmbNDTNH.Size = new System.Drawing.Size(109, 21);
            this.cmbNDTNH.TabIndex = 30;
            // 
            // cmbNH
            // 
            this.cmbNH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNH.FormattingEnabled = true;
            this.cmbNH.Location = new System.Drawing.Point(192, 83);
            this.cmbNH.Name = "cmbNH";
            this.cmbNH.Size = new System.Drawing.Size(109, 21);
            this.cmbNH.TabIndex = 29;
            this.cmbNH.SelectedIndexChanged += new System.EventHandler(this.cmbNH_SelectedIndexChanged);
            // 
            // txtTenNH
            // 
            this.txtTenNH.Location = new System.Drawing.Point(445, 83);
            this.txtTenNH.Name = "txtTenNH";
            this.txtTenNH.Size = new System.Drawing.Size(246, 21);
            this.txtTenNH.TabIndex = 28;
            // 
            // txtSodu
            // 
            this.txtSodu.Location = new System.Drawing.Point(445, 34);
            this.txtSodu.Name = "txtSodu";
            this.txtSodu.Size = new System.Drawing.Size(246, 21);
            this.txtSodu.TabIndex = 27;
            // 
            // txtMaTKNH
            // 
            this.txtMaTKNH.Location = new System.Drawing.Point(192, 34);
            this.txtMaTKNH.Name = "txtMaTKNH";
            this.txtMaTKNH.Size = new System.Drawing.Size(109, 21);
            this.txtMaTKNH.TabIndex = 24;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(59, 145);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(81, 13);
            this.label30.TabIndex = 23;
            this.label30.Text = "Mã nhà đầu tư:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(344, 86);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(83, 13);
            this.label29.TabIndex = 22;
            this.label29.Text = "Tên ngân hàng:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(344, 37);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(86, 13);
            this.label28.TabIndex = 21;
            this.label28.Text = "Số dư tài khoản:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(59, 86);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(79, 13);
            this.label27.TabIndex = 20;
            this.label27.Text = "Mã ngân hàng:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(59, 37);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(126, 13);
            this.label26.TabIndex = 19;
            this.label26.Text = "Mã tài khoản ngân hàng:";
            // 
            // btnThoatTKNH
            // 
            this.btnThoatTKNH.Location = new System.Drawing.Point(671, 28);
            this.btnThoatTKNH.Name = "btnThoatTKNH";
            this.btnThoatTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnThoatTKNH.TabIndex = 17;
            this.btnThoatTKNH.Text = "Thoát";
            this.btnThoatTKNH.UseVisualStyleBackColor = true;
            this.btnThoatTKNH.Click += new System.EventHandler(this.btnThoatTKNH_Click);
            // 
            // btnRefreshTKNH
            // 
            this.btnRefreshTKNH.Location = new System.Drawing.Point(540, 28);
            this.btnRefreshTKNH.Name = "btnRefreshTKNH";
            this.btnRefreshTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnRefreshTKNH.TabIndex = 16;
            this.btnRefreshTKNH.Text = "Refresh";
            this.btnRefreshTKNH.UseVisualStyleBackColor = true;
            this.btnRefreshTKNH.Click += new System.EventHandler(this.btnRefreshTKNH_Click);
            // 
            // btnUndoTKNH
            // 
            this.btnUndoTKNH.Location = new System.Drawing.Point(414, 28);
            this.btnUndoTKNH.Name = "btnUndoTKNH";
            this.btnUndoTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnUndoTKNH.TabIndex = 15;
            this.btnUndoTKNH.Text = "Undo";
            this.btnUndoTKNH.UseVisualStyleBackColor = true;
            this.btnUndoTKNH.Click += new System.EventHandler(this.btnUndoTKNH_Click);
            // 
            // btnSuaTKNH
            // 
            this.btnSuaTKNH.Location = new System.Drawing.Point(282, 28);
            this.btnSuaTKNH.Name = "btnSuaTKNH";
            this.btnSuaTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnSuaTKNH.TabIndex = 14;
            this.btnSuaTKNH.Text = "Sửa";
            this.btnSuaTKNH.UseVisualStyleBackColor = true;
            this.btnSuaTKNH.Click += new System.EventHandler(this.btnSuaTKNH_Click);
            // 
            // btnXoaTKNH
            // 
            this.btnXoaTKNH.Location = new System.Drawing.Point(148, 28);
            this.btnXoaTKNH.Name = "btnXoaTKNH";
            this.btnXoaTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnXoaTKNH.TabIndex = 13;
            this.btnXoaTKNH.Text = "Xóa";
            this.btnXoaTKNH.UseVisualStyleBackColor = true;
            this.btnXoaTKNH.Click += new System.EventHandler(this.btnXoaTKNH_Click);
            // 
            // btnThemTKNH
            // 
            this.btnThemTKNH.Location = new System.Drawing.Point(26, 28);
            this.btnThemTKNH.Name = "btnThemTKNH";
            this.btnThemTKNH.Size = new System.Drawing.Size(75, 23);
            this.btnThemTKNH.TabIndex = 12;
            this.btnThemTKNH.Text = "Thêm";
            this.btnThemTKNH.UseVisualStyleBackColor = true;
            this.btnThemTKNH.Click += new System.EventHandler(this.btnThemTKNH_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dgvPGD);
            this.tabPage4.Controls.Add(this.gbPGD);
            this.tabPage4.Controls.Add(this.btnThoatPGD);
            this.tabPage4.Controls.Add(this.btnRefreshPGD);
            this.tabPage4.Controls.Add(this.btnUndoPGD);
            this.tabPage4.Controls.Add(this.btnSuaPGD);
            this.tabPage4.Controls.Add(this.btnThemPGD);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(782, 557);
            this.tabPage4.TabIndex = 5;
            this.tabPage4.Text = "Phí giao dịch";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dgvPGD
            // 
            this.dgvPGD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPGD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaLGD,
            this.NgayGio,
            this.GiaPhi});
            this.dgvPGD.Location = new System.Drawing.Point(34, 332);
            this.dgvPGD.Name = "dgvPGD";
            this.dgvPGD.Size = new System.Drawing.Size(717, 196);
            this.dgvPGD.TabIndex = 31;
            this.dgvPGD.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPGD_CellContentClick);
            // 
            // MaLGD
            // 
            this.MaLGD.DataPropertyName = "MaLGD";
            this.MaLGD.HeaderText = "Mã loại giao dịch";
            this.MaLGD.Name = "MaLGD";
            this.MaLGD.Width = 113;
            // 
            // NgayGio
            // 
            this.NgayGio.DataPropertyName = "NgayGio";
            this.NgayGio.HeaderText = "Ngày/Giờ";
            this.NgayGio.MinimumWidth = 6;
            this.NgayGio.Name = "NgayGio";
            this.NgayGio.Width = 125;
            // 
            // GiaPhi
            // 
            this.GiaPhi.DataPropertyName = "GiaPhi";
            this.GiaPhi.HeaderText = "Phí giao dịch";
            this.GiaPhi.MinimumWidth = 6;
            this.GiaPhi.Name = "GiaPhi";
            this.GiaPhi.Width = 125;
            // 
            // gbPGD
            // 
            this.gbPGD.Controls.Add(this.btnHuyPGD);
            this.gbPGD.Controls.Add(this.btnGhiPGD);
            this.gbPGD.Controls.Add(this.cmbMaLGD);
            this.gbPGD.Controls.Add(this.dtpPGD);
            this.gbPGD.Controls.Add(this.txtGiaPhi);
            this.gbPGD.Controls.Add(this.label43);
            this.gbPGD.Controls.Add(this.label44);
            this.gbPGD.Controls.Add(this.label45);
            this.gbPGD.Location = new System.Drawing.Point(34, 75);
            this.gbPGD.Name = "gbPGD";
            this.gbPGD.Size = new System.Drawing.Size(717, 241);
            this.gbPGD.TabIndex = 28;
            this.gbPGD.TabStop = false;
            // 
            // btnHuyPGD
            // 
            this.btnHuyPGD.Location = new System.Drawing.Point(449, 178);
            this.btnHuyPGD.Name = "btnHuyPGD";
            this.btnHuyPGD.Size = new System.Drawing.Size(75, 23);
            this.btnHuyPGD.TabIndex = 31;
            this.btnHuyPGD.Text = "Hủy";
            this.btnHuyPGD.UseVisualStyleBackColor = true;
            this.btnHuyPGD.Click += new System.EventHandler(this.btnHuyPGD_Click);
            // 
            // btnGhiPGD
            // 
            this.btnGhiPGD.Location = new System.Drawing.Point(204, 178);
            this.btnGhiPGD.Name = "btnGhiPGD";
            this.btnGhiPGD.Size = new System.Drawing.Size(75, 23);
            this.btnGhiPGD.TabIndex = 30;
            this.btnGhiPGD.Text = "Ghi";
            this.btnGhiPGD.UseVisualStyleBackColor = true;
            this.btnGhiPGD.Click += new System.EventHandler(this.btnGhiPGD_Click);
            // 
            // cmbMaLGD
            // 
            this.cmbMaLGD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaLGD.FormattingEnabled = true;
            this.cmbMaLGD.Location = new System.Drawing.Point(163, 34);
            this.cmbMaLGD.Name = "cmbMaLGD";
            this.cmbMaLGD.Size = new System.Drawing.Size(121, 21);
            this.cmbMaLGD.TabIndex = 29;
            // 
            // dtpPGD
            // 
            this.dtpPGD.CustomFormat = "ddddd, MMMM dd, yyyy hh:mm:ss ";
            this.dtpPGD.Location = new System.Drawing.Point(192, 80);
            this.dtpPGD.Name = "dtpPGD";
            this.dtpPGD.Size = new System.Drawing.Size(204, 21);
            this.dtpPGD.TabIndex = 28;
            // 
            // txtGiaPhi
            // 
            this.txtGiaPhi.Location = new System.Drawing.Point(413, 34);
            this.txtGiaPhi.Name = "txtGiaPhi";
            this.txtGiaPhi.Size = new System.Drawing.Size(161, 21);
            this.txtGiaPhi.TabIndex = 27;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(344, 37);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(43, 13);
            this.label43.TabIndex = 21;
            this.label43.Text = "Giá phí:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(59, 86);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(55, 13);
            this.label44.TabIndex = 20;
            this.label44.Text = "Ngày/Giờ:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(59, 37);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(89, 13);
            this.label45.TabIndex = 19;
            this.label45.Text = "Mã loại giao dịch:";
            // 
            // btnThoatPGD
            // 
            this.btnThoatPGD.Location = new System.Drawing.Point(676, 28);
            this.btnThoatPGD.Name = "btnThoatPGD";
            this.btnThoatPGD.Size = new System.Drawing.Size(75, 23);
            this.btnThoatPGD.TabIndex = 27;
            this.btnThoatPGD.Text = "Thoát";
            this.btnThoatPGD.UseVisualStyleBackColor = true;
            this.btnThoatPGD.Click += new System.EventHandler(this.btnThoatPGD_Click);
            // 
            // btnRefreshPGD
            // 
            this.btnRefreshPGD.Location = new System.Drawing.Point(515, 28);
            this.btnRefreshPGD.Name = "btnRefreshPGD";
            this.btnRefreshPGD.Size = new System.Drawing.Size(75, 23);
            this.btnRefreshPGD.TabIndex = 26;
            this.btnRefreshPGD.Text = "Refresh";
            this.btnRefreshPGD.UseVisualStyleBackColor = true;
            this.btnRefreshPGD.Click += new System.EventHandler(this.btnRefreshPGD_Click);
            // 
            // btnUndoPGD
            // 
            this.btnUndoPGD.Location = new System.Drawing.Point(355, 28);
            this.btnUndoPGD.Name = "btnUndoPGD";
            this.btnUndoPGD.Size = new System.Drawing.Size(75, 23);
            this.btnUndoPGD.TabIndex = 25;
            this.btnUndoPGD.Text = "Undo";
            this.btnUndoPGD.UseVisualStyleBackColor = true;
            this.btnUndoPGD.Click += new System.EventHandler(this.btnUndoPGD_Click);
            // 
            // btnSuaPGD
            // 
            this.btnSuaPGD.Location = new System.Drawing.Point(186, 28);
            this.btnSuaPGD.Name = "btnSuaPGD";
            this.btnSuaPGD.Size = new System.Drawing.Size(75, 23);
            this.btnSuaPGD.TabIndex = 24;
            this.btnSuaPGD.Text = "Sửa";
            this.btnSuaPGD.UseVisualStyleBackColor = true;
            this.btnSuaPGD.Click += new System.EventHandler(this.btnSuaPGD_Click);
            // 
            // btnThemPGD
            // 
            this.btnThemPGD.Location = new System.Drawing.Point(31, 28);
            this.btnThemPGD.Name = "btnThemPGD";
            this.btnThemPGD.Size = new System.Drawing.Size(75, 23);
            this.btnThemPGD.TabIndex = 22;
            this.btnThemPGD.Text = "Thêm";
            this.btnThemPGD.UseVisualStyleBackColor = true;
            this.btnThemPGD.Click += new System.EventHandler(this.btnThemPGD_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dgvTraCuuCP);
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Controls.Add(this.btnRP);
            this.tabPage5.Controls.Add(this.btnThoatSD);
            this.tabPage5.Controls.Add(this.cmbNDT);
            this.tabPage5.Controls.Add(this.label31);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(782, 557);
            this.tabPage5.TabIndex = 3;
            this.tabPage5.Text = "Tra số dư";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dgvTraCuuCP
            // 
            this.dgvTraCuuCP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTraCuuCP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaLD,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.GiaoDich,
            this.MaCP,
            this.SoLuongDat,
            this.GiaDat,
            this.SoLuongKhop,
            this.GiaKhop,
            this.TenTT});
            this.dgvTraCuuCP.Location = new System.Drawing.Point(66, 295);
            this.dgvTraCuuCP.Margin = new System.Windows.Forms.Padding(2);
            this.dgvTraCuuCP.Name = "dgvTraCuuCP";
            this.dgvTraCuuCP.RowHeadersWidth = 51;
            this.dgvTraCuuCP.RowTemplate.Height = 24;
            this.dgvTraCuuCP.Size = new System.Drawing.Size(651, 235);
            this.dgvTraCuuCP.TabIndex = 6;
            // 
            // MaLD
            // 
            this.MaLD.DataPropertyName = "MaLD";
            this.MaLD.HeaderText = "Mã lệnh đặt";
            this.MaLD.Name = "MaLD";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NgayGio";
            this.dataGridViewTextBoxColumn1.HeaderText = "Ngày giờ đặt";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "MaTKNH";
            this.dataGridViewTextBoxColumn2.HeaderText = "Mã tài khoản ngân hàng";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // GiaoDich
            // 
            this.GiaoDich.DataPropertyName = "TenLoaiGiaoDich";
            this.GiaoDich.HeaderText = "Giao dịch";
            this.GiaoDich.Name = "GiaoDich";
            // 
            // MaCP
            // 
            this.MaCP.DataPropertyName = "MaCP";
            this.MaCP.HeaderText = "Mã cổ phiếu";
            this.MaCP.Name = "MaCP";
            // 
            // SoLuongDat
            // 
            this.SoLuongDat.DataPropertyName = "SoLuongDat";
            this.SoLuongDat.HeaderText = "Số lượng đặt";
            this.SoLuongDat.Name = "SoLuongDat";
            // 
            // GiaDat
            // 
            this.GiaDat.DataPropertyName = "GiaDat";
            this.GiaDat.HeaderText = "Giá đặt";
            this.GiaDat.Name = "GiaDat";
            // 
            // SoLuongKhop
            // 
            this.SoLuongKhop.DataPropertyName = "SoLuongKhop";
            this.SoLuongKhop.HeaderText = "Số lượng khớp";
            this.SoLuongKhop.Name = "SoLuongKhop";
            // 
            // GiaKhop
            // 
            this.GiaKhop.DataPropertyName = "GiaKhop";
            this.GiaKhop.HeaderText = "Giá Khớp";
            this.GiaKhop.Name = "GiaKhop";
            // 
            // TenTT
            // 
            this.TenTT.DataPropertyName = "TenTT";
            this.TenTT.HeaderText = "Trạng thái";
            this.TenTT.Name = "TenTT";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTenNHSD);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.cmbMaNH);
            this.groupBox1.Controls.Add(this.txtSoduGD);
            this.groupBox1.Controls.Add(this.txtMaTKNHSD);
            this.groupBox1.Controls.Add(this.txtTenNDTSD);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Location = new System.Drawing.Point(77, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(628, 177);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // txtTenNHSD
            // 
            this.txtTenNHSD.Location = new System.Drawing.Point(378, 82);
            this.txtTenNHSD.Name = "txtTenNHSD";
            this.txtTenNHSD.Size = new System.Drawing.Size(232, 21);
            this.txtTenNHSD.TabIndex = 9;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(33, 85);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(79, 13);
            this.label36.TabIndex = 8;
            this.label36.Text = "Mã ngân hàng:";
            // 
            // cmbMaNH
            // 
            this.cmbMaNH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaNH.FormattingEnabled = true;
            this.cmbMaNH.Location = new System.Drawing.Point(128, 82);
            this.cmbMaNH.Name = "cmbMaNH";
            this.cmbMaNH.Size = new System.Drawing.Size(100, 21);
            this.cmbMaNH.TabIndex = 7;
            this.cmbMaNH.SelectedIndexChanged += new System.EventHandler(this.cmbMaNH_SelectedIndexChanged);
            // 
            // txtSoduGD
            // 
            this.txtSoduGD.Location = new System.Drawing.Point(181, 130);
            this.txtSoduGD.Name = "txtSoduGD";
            this.txtSoduGD.Size = new System.Drawing.Size(100, 21);
            this.txtSoduGD.TabIndex = 6;
            // 
            // txtMaTKNHSD
            // 
            this.txtMaTKNHSD.Location = new System.Drawing.Point(418, 38);
            this.txtMaTKNHSD.Name = "txtMaTKNHSD";
            this.txtMaTKNHSD.Size = new System.Drawing.Size(100, 21);
            this.txtMaTKNHSD.TabIndex = 5;
            // 
            // txtTenNDTSD
            // 
            this.txtTenNDTSD.Location = new System.Drawing.Point(128, 33);
            this.txtTenNDTSD.Name = "txtTenNDTSD";
            this.txtTenNDTSD.Size = new System.Drawing.Size(100, 21);
            this.txtTenNDTSD.TabIndex = 4;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(33, 133);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(131, 13);
            this.label35.TabIndex = 3;
            this.label35.Text = "Số dư cho phép giao dịch:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(277, 85);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(83, 13);
            this.label34.TabIndex = 2;
            this.label34.Text = "Tên ngân hàng:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(277, 41);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(126, 13);
            this.label33.TabIndex = 1;
            this.label33.Text = "Mã tài khoản ngân hàng:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(33, 36);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 13);
            this.label32.TabIndex = 0;
            this.label32.Text = "Tên nhà đầu tư:";
            // 
            // btnRP
            // 
            this.btnRP.Location = new System.Drawing.Point(576, 27);
            this.btnRP.Name = "btnRP";
            this.btnRP.Size = new System.Drawing.Size(90, 23);
            this.btnRP.TabIndex = 3;
            this.btnRP.Text = "Xem báo cáo";
            this.btnRP.UseVisualStyleBackColor = true;
            this.btnRP.Click += new System.EventHandler(this.btnRP_Click);
            // 
            // btnThoatSD
            // 
            this.btnThoatSD.Location = new System.Drawing.Point(426, 27);
            this.btnThoatSD.Name = "btnThoatSD";
            this.btnThoatSD.Size = new System.Drawing.Size(75, 23);
            this.btnThoatSD.TabIndex = 2;
            this.btnThoatSD.Text = "Thoát";
            this.btnThoatSD.UseVisualStyleBackColor = true;
            this.btnThoatSD.Click += new System.EventHandler(this.btnThoatSD_Click);
            // 
            // cmbNDT
            // 
            this.cmbNDT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNDT.FormattingEnabled = true;
            this.cmbNDT.Location = new System.Drawing.Point(216, 29);
            this.cmbNDT.Name = "cmbNDT";
            this.cmbNDT.Size = new System.Drawing.Size(121, 21);
            this.cmbNDT.TabIndex = 1;
            this.cmbNDT.SelectedIndexChanged += new System.EventHandler(this.cmbNDT_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(114, 32);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(81, 13);
            this.label31.TabIndex = 0;
            this.label31.Text = "Mã nhà đầu tư:";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.cmbMaNV);
            this.tabPage6.Controls.Add(this.cmbNhom);
            this.tabPage6.Controls.Add(this.btnThoatLG);
            this.tabPage6.Controls.Add(this.btnXacNhanLG);
            this.tabPage6.Controls.Add(this.label37);
            this.tabPage6.Controls.Add(this.label38);
            this.tabPage6.Controls.Add(this.label39);
            this.tabPage6.Controls.Add(this.label40);
            this.tabPage6.Controls.Add(this.txtTenLG);
            this.tabPage6.Controls.Add(this.txtMKLG);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(782, 557);
            this.tabPage6.TabIndex = 4;
            this.tabPage6.Text = "Tạo login";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // cmbMaNV
            // 
            this.cmbMaNV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaNV.FormattingEnabled = true;
            this.cmbMaNV.Location = new System.Drawing.Point(238, 156);
            this.cmbMaNV.Name = "cmbMaNV";
            this.cmbMaNV.Size = new System.Drawing.Size(93, 21);
            this.cmbMaNV.TabIndex = 27;
            // 
            // cmbNhom
            // 
            this.cmbNhom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNhom.FormattingEnabled = true;
            this.cmbNhom.Items.AddRange(new object[] {
            "CONGTY",
            "NHADAUTU"});
            this.cmbNhom.Location = new System.Drawing.Point(238, 73);
            this.cmbNhom.Name = "cmbNhom";
            this.cmbNhom.Size = new System.Drawing.Size(93, 21);
            this.cmbNhom.TabIndex = 26;
            this.cmbNhom.SelectedIndexChanged += new System.EventHandler(this.cmbNhom_SelectedIndexChanged);
            // 
            // btnThoatLG
            // 
            this.btnThoatLG.Location = new System.Drawing.Point(475, 254);
            this.btnThoatLG.Name = "btnThoatLG";
            this.btnThoatLG.Size = new System.Drawing.Size(75, 23);
            this.btnThoatLG.TabIndex = 25;
            this.btnThoatLG.Text = "Thoát";
            this.btnThoatLG.UseVisualStyleBackColor = true;
            this.btnThoatLG.Click += new System.EventHandler(this.btnThoatLG_Click);
            // 
            // btnXacNhanLG
            // 
            this.btnXacNhanLG.Location = new System.Drawing.Point(227, 254);
            this.btnXacNhanLG.Name = "btnXacNhanLG";
            this.btnXacNhanLG.Size = new System.Drawing.Size(75, 23);
            this.btnXacNhanLG.TabIndex = 24;
            this.btnXacNhanLG.Text = "Xác nhận";
            this.btnXacNhanLG.UseVisualStyleBackColor = true;
            this.btnXacNhanLG.Click += new System.EventHandler(this.btnXacNhanLG_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(423, 76);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(83, 13);
            this.label37.TabIndex = 19;
            this.label37.Text = "Tên đăng nhập:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(146, 76);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(71, 13);
            this.label38.TabIndex = 18;
            this.label38.Text = "Nhóm quyền:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(162, 159);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(25, 13);
            this.label39.TabIndex = 17;
            this.label39.Text = "Mã:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(423, 159);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(55, 13);
            this.label40.TabIndex = 16;
            this.label40.Text = "Mật khẩu:";
            // 
            // txtTenLG
            // 
            this.txtTenLG.Location = new System.Drawing.Point(521, 71);
            this.txtTenLG.Margin = new System.Windows.Forms.Padding(2);
            this.txtTenLG.Name = "txtTenLG";
            this.txtTenLG.Size = new System.Drawing.Size(86, 21);
            this.txtTenLG.TabIndex = 21;
            // 
            // txtMKLG
            // 
            this.txtMKLG.Location = new System.Drawing.Point(521, 156);
            this.txtMKLG.Margin = new System.Windows.Forms.Padding(2);
            this.txtMKLG.Name = "txtMKLG";
            this.txtMKLG.PasswordChar = '*';
            this.txtMKLG.Size = new System.Drawing.Size(86, 21);
            this.txtMKLG.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.LBCongty);
            this.panel1.Controls.Add(this.LBQuyen);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.LBTen);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.LBMa);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 585);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(790, 88);
            this.panel1.TabIndex = 1;
            // 
            // LBCongty
            // 
            this.LBCongty.AutoSize = true;
            this.LBCongty.Location = new System.Drawing.Point(613, 40);
            this.LBCongty.Name = "LBCongty";
            this.LBCongty.Size = new System.Drawing.Size(35, 13);
            this.LBCongty.TabIndex = 6;
            this.LBCongty.Text = "label7";
            // 
            // LBQuyen
            // 
            this.LBQuyen.AutoSize = true;
            this.LBQuyen.Location = new System.Drawing.Point(458, 40);
            this.LBQuyen.Name = "LBQuyen";
            this.LBQuyen.Size = new System.Drawing.Size(35, 13);
            this.LBQuyen.TabIndex = 5;
            this.LBQuyen.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(409, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Quyền:";
            // 
            // LBTen
            // 
            this.LBTen.AutoSize = true;
            this.LBTen.Location = new System.Drawing.Point(239, 40);
            this.LBTen.Name = "LBTen";
            this.LBTen.Size = new System.Drawing.Size(35, 13);
            this.LBTen.TabIndex = 3;
            this.LBTen.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(175, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Họ và tên:";
            // 
            // LBMa
            // 
            this.LBMa.AutoSize = true;
            this.LBMa.Location = new System.Drawing.Point(43, 40);
            this.LBMa.Name = "LBMa";
            this.LBMa.Size = new System.Drawing.Size(35, 13);
            this.LBMa.TabIndex = 1;
            this.LBMa.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã:";
            // 
            // FormCongTy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 674);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormCongTy";
            this.Text = "FormCongTy";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormCongTy_FormClosing);
            this.Load += new System.EventHandler(this.FormCongTy_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.gbNhanVien.ResumeLayout(false);
            this.gbNhanVien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nghiCheckEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phaiCheckedit.Properties)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhaDauTu)).EndInit();
            this.gbNhaDauTu.ResumeLayout(false);
            this.gbNhaDauTu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.phaicheckEditNDT.Properties)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTKNH)).EndInit();
            this.gbTKNH.ResumeLayout(false);
            this.gbTKNH.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPGD)).EndInit();
            this.gbPGD.ResumeLayout(false);
            this.gbPGD.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTraCuuCP)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LBCongty;
        private System.Windows.Forms.Label LBQuyen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LBTen;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LBMa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnThoatNV;
        private System.Windows.Forms.Button btnLamMoiNV;
        private System.Windows.Forms.Button btnUndoNV;
        private System.Windows.Forms.Button btnSuaNV;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.GroupBox gbNhanVien;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnGhi;
        private System.Windows.Forms.TextBox txtDiachiNV;
        private System.Windows.Forms.DateTimePicker dtpNgaysinhNV;
        private System.Windows.Forms.TextBox txtTenNV;
        private System.Windows.Forms.TextBox txtHoNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.CheckEdit nghiCheckEdit;
        private System.Windows.Forms.TextBox txtSDT;
        private DevExpress.XtraEditors.CheckEdit phaiCheckedit;
        private System.Windows.Forms.Button btnThoatNDT;
        private System.Windows.Forms.Button btnRefreshNDT;
        private System.Windows.Forms.Button btnUndoNDT;
        private System.Windows.Forms.Button btnSuaNDT;
        private System.Windows.Forms.Button btnXoaNDT;
        private System.Windows.Forms.Button btnThemNDT;
        private System.Windows.Forms.DataGridView dgvNhaDauTu;
        private System.Windows.Forms.GroupBox gbNhaDauTu;
        private System.Windows.Forms.TextBox txtMaNDT;
        private System.Windows.Forms.Button btnHuyNDT;
        private System.Windows.Forms.Button btnGhiNDT;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtEmailNDT;
        private System.Windows.Forms.TextBox txtTenNDT;
        private System.Windows.Forms.TextBox txtHoNDT;
        private System.Windows.Forms.DateTimePicker dtpNgayCap;
        private System.Windows.Forms.DateTimePicker dtpNgaysinhNDT;
        private DevExpress.XtraEditors.CheckEdit phaicheckEditNDT;
        private System.Windows.Forms.TextBox txtMKDL;
        private System.Windows.Forms.TextBox txtMKGD;
        private System.Windows.Forms.TextBox txtQuocgia;
        private System.Windows.Forms.TextBox txtPassport;
        private System.Windows.Forms.TextBox txtCMND;
        private System.Windows.Forms.TextBox txtSDTNDT;
        private System.Windows.Forms.TextBox txtDiachiNDT;
        private System.Windows.Forms.GroupBox gbTKNH;
        private System.Windows.Forms.TextBox txtTenNH;
        private System.Windows.Forms.TextBox txtSodu;
        private System.Windows.Forms.TextBox txtMaTKNH;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnThoatTKNH;
        private System.Windows.Forms.Button btnRefreshTKNH;
        private System.Windows.Forms.Button btnUndoTKNH;
        private System.Windows.Forms.Button btnSuaTKNH;
        private System.Windows.Forms.Button btnXoaTKNH;
        private System.Windows.Forms.Button btnThemTKNH;
        private System.Windows.Forms.DataGridView dgvTKNH;
        private System.Windows.Forms.ComboBox cmbNH;
        private System.Windows.Forms.ComboBox cmbNDTNH;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbMaNH;
        private System.Windows.Forms.TextBox txtSoduGD;
        private System.Windows.Forms.TextBox txtMaTKNHSD;
        private System.Windows.Forms.TextBox txtTenNDTSD;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button btnRP;
        private System.Windows.Forms.Button btnThoatSD;
        private System.Windows.Forms.ComboBox cmbNDT;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtTenNHSD;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenNV;
        private System.Windows.Forms.DataGridViewCheckBoxColumn PhaiNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgaySinhNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChiNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoDTNV;
        private System.Windows.Forms.DataGridViewCheckBoxColumn DaNghiViec;
        private System.Windows.Forms.Button btnThoatLG;
        private System.Windows.Forms.Button btnXacNhanLG;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtTenLG;
        private System.Windows.Forms.TextBox txtMKLG;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTK;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoNDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenNDT;
        private System.Windows.Forms.DataGridViewCheckBoxColumn PhaiNDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChiNDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoDTNDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn CMND;
        private System.Windows.Forms.DataGridViewTextBoxColumn Passport;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgaySinhNDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayCap;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuocGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn MKGiaoDich;
        private System.Windows.Forms.DataGridViewTextBoxColumn MKDatLenh;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTKNH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNH;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoDuTKNH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTKSD;
        private System.Windows.Forms.ComboBox cmbNhom;
        private System.Windows.Forms.ComboBox cmbMaNV;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dgvPGD;
        private System.Windows.Forms.GroupBox gbPGD;
        private System.Windows.Forms.TextBox txtGiaPhi;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button btnThoatPGD;
        private System.Windows.Forms.Button btnRefreshPGD;
        private System.Windows.Forms.Button btnUndoPGD;
        private System.Windows.Forms.Button btnSuaPGD;
        private System.Windows.Forms.Button btnThemPGD;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLGD;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayGio;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaPhi;
        private System.Windows.Forms.DateTimePicker dtpPGD;
        private System.Windows.Forms.ComboBox cmbMaLGD;
        private System.Windows.Forms.Button btnHuyTKNH;
        private System.Windows.Forms.Button btnGhiTKNH;
        private System.Windows.Forms.Button btnHuyPGD;
        private System.Windows.Forms.Button btnGhiPGD;
        private System.Windows.Forms.DataGridView dgvTraCuuCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLD;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaoDich;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongKhop;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaKhop;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenTT;
    }
}