﻿namespace QLGDCK
{
    partial class FormSoGiaoDich
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.MaNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhaiNV = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SoDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgaySinhNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChiNV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DaNghiViec = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gbNhanVien = new System.Windows.Forms.GroupBox();
            this.nghiCheckEdit = new DevExpress.XtraEditors.CheckEdit();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.phaiCheckedit = new DevExpress.XtraEditors.CheckEdit();
            this.btnHuy = new System.Windows.Forms.Button();
            this.txtDiachiNV = new System.Windows.Forms.TextBox();
            this.btnGhi = new System.Windows.Forms.Button();
            this.dtpNgaysinhNV = new System.Windows.Forms.DateTimePicker();
            this.txtTenNV = new System.Windows.Forms.TextBox();
            this.txtHoNV = new System.Windows.Forms.TextBox();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnThoatNV = new System.Windows.Forms.Button();
            this.btnLamMoiNV = new System.Windows.Forms.Button();
            this.btnUndoNV = new System.Windows.Forms.Button();
            this.btnSuaNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnXoaCP = new System.Windows.Forms.Button();
            this.btnSuaCP = new System.Windows.Forms.Button();
            this.btnThoatCP = new System.Windows.Forms.Button();
            this.btnThemCP = new System.Windows.Forms.Button();
            this.dgvCoPhieu = new System.Windows.Forms.DataGridView();
            this.MaCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiaChiCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SDTCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Website = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbCoPhieu = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btnHuyCP = new System.Windows.Forms.Button();
            this.btnXacNhanCP = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSoLuongCP = new System.Windows.Forms.TextBox();
            this.txtWebsiteCT = new System.Windows.Forms.TextBox();
            this.txtTenCP = new System.Windows.Forms.TextBox();
            this.txtDiaChiCT = new System.Windows.Forms.TextBox();
            this.txtSDTCT = new System.Windows.Forms.TextBox();
            this.txtFaxCT = new System.Windows.Forms.TextBox();
            this.txtMaCP = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnHuyGiaCP = new System.Windows.Forms.Button();
            this.btnHuyQD = new System.Windows.Forms.Button();
            this.btnSuaGia = new System.Windows.Forms.Button();
            this.btnThemGia = new System.Windows.Forms.Button();
            this.dgvCapNhat = new System.Windows.Forms.DataGridView();
            this.MaSGD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ngay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MoTaQuyDinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaQuyDinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSuaQuyDinh = new System.Windows.Forms.Button();
            this.gbGiaCP = new System.Windows.Forms.GroupBox();
            this.dtpNgay1 = new System.Windows.Forms.DateTimePicker();
            this.btnRefreshGiaCP = new System.Windows.Forms.Button();
            this.txtGiaDongCua = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtGiaSan = new System.Windows.Forms.TextBox();
            this.txtGiaThamChieu = new System.Windows.Forms.TextBox();
            this.cmbCP = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnXacNhanGia = new System.Windows.Forms.Button();
            this.txtGiaTran = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.gbQuyDinh = new System.Windows.Forms.GroupBox();
            this.dtpNgayGio = new System.Windows.Forms.DateTimePicker();
            this.cmbQuyDinh = new System.Windows.Forms.ComboBox();
            this.txtGiaQuyDinh = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnXacNhanQD = new System.Windows.Forms.Button();
            this.txtMaSan = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.dgvGiaCP = new System.Windows.Forms.DataGridView();
            this.MaCP1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayGio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaSan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaThamChieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaTran = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaDongCua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnThemQuyDinh = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.dgvLenhDat = new System.Windows.Forms.DataGridView();
            this.dgvKhopLenh = new System.Windows.Forms.DataGridView();
            this.MaKL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayGio2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongKhop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhiGiaoDich = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaKhop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLD1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.txtQuyen = new System.Windows.Forms.TextBox();
            this.cmbMaNV = new System.Windows.Forms.ComboBox();
            this.btnThoatLG = new System.Windows.Forms.Button();
            this.btnXacNhanLG = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtTenLG = new System.Windows.Forms.TextBox();
            this.txtMKLG = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LBSan = new System.Windows.Forms.Label();
            this.LBQuyen = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LBTen = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LBMa = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.MaLD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongDat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaDat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayGio1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaTKNH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaLGD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaCP2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.gbNhanVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nghiCheckEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phaiCheckedit.Properties)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoPhieu)).BeginInit();
            this.gbCoPhieu.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCapNhat)).BeginInit();
            this.gbGiaCP.SuspendLayout();
            this.gbQuyDinh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGiaCP)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLenhDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhopLenh)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(0, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(783, 541);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvNhanVien);
            this.tabPage1.Controls.Add(this.gbNhanVien);
            this.tabPage1.Controls.Add(this.btnThoatNV);
            this.tabPage1.Controls.Add(this.btnLamMoiNV);
            this.tabPage1.Controls.Add(this.btnUndoNV);
            this.tabPage1.Controls.Add(this.btnSuaNV);
            this.tabPage1.Controls.Add(this.btnXoaNV);
            this.tabPage1.Controls.Add(this.btnThemNV);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(775, 515);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Nhân viên";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaNV,
            this.HoNV,
            this.TenNV,
            this.PhaiNV,
            this.SoDT,
            this.NgaySinhNV,
            this.DiaChiNV,
            this.DaNghiViec});
            this.dgvNhanVien.Location = new System.Drawing.Point(27, 302);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.Size = new System.Drawing.Size(720, 196);
            this.dgvNhanVien.TabIndex = 26;
            this.dgvNhanVien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNhanVien_CellContentClick);
            // 
            // MaNV
            // 
            this.MaNV.DataPropertyName = "MaNV";
            this.MaNV.HeaderText = "Mã nhân viên";
            this.MaNV.Name = "MaNV";
            // 
            // HoNV
            // 
            this.HoNV.DataPropertyName = "Ho";
            this.HoNV.HeaderText = "Họ";
            this.HoNV.Name = "HoNV";
            // 
            // TenNV
            // 
            this.TenNV.DataPropertyName = "Ten";
            this.TenNV.HeaderText = "Tên";
            this.TenNV.Name = "TenNV";
            // 
            // PhaiNV
            // 
            this.PhaiNV.DataPropertyName = "Phai";
            this.PhaiNV.HeaderText = "Phái";
            this.PhaiNV.Name = "PhaiNV";
            this.PhaiNV.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.PhaiNV.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // SoDT
            // 
            this.SoDT.DataPropertyName = "SoDT";
            this.SoDT.HeaderText = "Số điện thoại";
            this.SoDT.Name = "SoDT";
            // 
            // NgaySinhNV
            // 
            this.NgaySinhNV.DataPropertyName = "NgaySinh";
            this.NgaySinhNV.HeaderText = "Ngày sinh";
            this.NgaySinhNV.Name = "NgaySinhNV";
            // 
            // DiaChiNV
            // 
            this.DiaChiNV.DataPropertyName = "DiaChi";
            this.DiaChiNV.HeaderText = "Địa chỉ";
            this.DiaChiNV.Name = "DiaChiNV";
            // 
            // DaNghiViec
            // 
            this.DaNghiViec.DataPropertyName = "DaNghiViec";
            this.DaNghiViec.HeaderText = "Đã nghỉ việc";
            this.DaNghiViec.Name = "DaNghiViec";
            this.DaNghiViec.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DaNghiViec.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // gbNhanVien
            // 
            this.gbNhanVien.Controls.Add(this.nghiCheckEdit);
            this.gbNhanVien.Controls.Add(this.txtSDT);
            this.gbNhanVien.Controls.Add(this.phaiCheckedit);
            this.gbNhanVien.Controls.Add(this.btnHuy);
            this.gbNhanVien.Controls.Add(this.txtDiachiNV);
            this.gbNhanVien.Controls.Add(this.btnGhi);
            this.gbNhanVien.Controls.Add(this.dtpNgaysinhNV);
            this.gbNhanVien.Controls.Add(this.txtTenNV);
            this.gbNhanVien.Controls.Add(this.txtHoNV);
            this.gbNhanVien.Controls.Add(this.txtMaNV);
            this.gbNhanVien.Controls.Add(this.label11);
            this.gbNhanVien.Controls.Add(this.label10);
            this.gbNhanVien.Controls.Add(this.label9);
            this.gbNhanVien.Controls.Add(this.label8);
            this.gbNhanVien.Controls.Add(this.label7);
            this.gbNhanVien.Controls.Add(this.label6);
            this.gbNhanVien.Controls.Add(this.label4);
            this.gbNhanVien.Controls.Add(this.label2);
            this.gbNhanVien.Location = new System.Drawing.Point(27, 65);
            this.gbNhanVien.Name = "gbNhanVien";
            this.gbNhanVien.Size = new System.Drawing.Size(720, 231);
            this.gbNhanVien.TabIndex = 25;
            this.gbNhanVien.TabStop = false;
            // 
            // nghiCheckEdit
            // 
            this.nghiCheckEdit.Location = new System.Drawing.Point(627, 84);
            this.nghiCheckEdit.Name = "nghiCheckEdit";
            this.nghiCheckEdit.Properties.Caption = "Nghỉ";
            this.nghiCheckEdit.Size = new System.Drawing.Size(75, 20);
            this.nghiCheckEdit.TabIndex = 16;
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(592, 30);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(100, 21);
            this.txtSDT.TabIndex = 15;
            // 
            // phaiCheckedit
            // 
            this.phaiCheckedit.Location = new System.Drawing.Point(308, 30);
            this.phaiCheckedit.Name = "phaiCheckedit";
            this.phaiCheckedit.Properties.Caption = "Nam";
            this.phaiCheckedit.Size = new System.Drawing.Size(75, 20);
            this.phaiCheckedit.TabIndex = 12;
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(436, 192);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(75, 23);
            this.btnHuy.TabIndex = 28;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // txtDiachiNV
            // 
            this.txtDiachiNV.Location = new System.Drawing.Point(335, 146);
            this.txtDiachiNV.Name = "txtDiachiNV";
            this.txtDiachiNV.Size = new System.Drawing.Size(367, 21);
            this.txtDiachiNV.TabIndex = 14;
            // 
            // btnGhi
            // 
            this.btnGhi.Location = new System.Drawing.Point(212, 192);
            this.btnGhi.Name = "btnGhi";
            this.btnGhi.Size = new System.Drawing.Size(75, 23);
            this.btnGhi.TabIndex = 17;
            this.btnGhi.Text = "Ghi";
            this.btnGhi.UseVisualStyleBackColor = true;
            this.btnGhi.Click += new System.EventHandler(this.btnGhi_Click);
            // 
            // dtpNgaysinhNV
            // 
            this.dtpNgaysinhNV.Location = new System.Drawing.Point(335, 81);
            this.dtpNgaysinhNV.Name = "dtpNgaysinhNV";
            this.dtpNgaysinhNV.Size = new System.Drawing.Size(200, 21);
            this.dtpNgaysinhNV.TabIndex = 13;
            // 
            // txtTenNV
            // 
            this.txtTenNV.Location = new System.Drawing.Point(97, 146);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Size = new System.Drawing.Size(100, 21);
            this.txtTenNV.TabIndex = 11;
            // 
            // txtHoNV
            // 
            this.txtHoNV.Location = new System.Drawing.Point(97, 84);
            this.txtHoNV.Name = "txtHoNV";
            this.txtHoNV.Size = new System.Drawing.Size(100, 21);
            this.txtHoNV.TabIndex = 10;
            // 
            // txtMaNV
            // 
            this.txtMaNV.Location = new System.Drawing.Point(97, 30);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(100, 21);
            this.txtMaNV.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(554, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Đã nghỉ việc:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(501, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Số điện thoại:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(271, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Địa chỉ:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(271, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Ngày sinh:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(271, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Phái:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Tên:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Họ:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã nhân viên:";
            // 
            // btnThoatNV
            // 
            this.btnThoatNV.Location = new System.Drawing.Point(672, 20);
            this.btnThoatNV.Name = "btnThoatNV";
            this.btnThoatNV.Size = new System.Drawing.Size(75, 23);
            this.btnThoatNV.TabIndex = 24;
            this.btnThoatNV.Text = "Thoát";
            this.btnThoatNV.UseVisualStyleBackColor = true;
            this.btnThoatNV.Click += new System.EventHandler(this.btnThoatNV_Click);
            // 
            // btnLamMoiNV
            // 
            this.btnLamMoiNV.Location = new System.Drawing.Point(541, 20);
            this.btnLamMoiNV.Name = "btnLamMoiNV";
            this.btnLamMoiNV.Size = new System.Drawing.Size(75, 23);
            this.btnLamMoiNV.TabIndex = 23;
            this.btnLamMoiNV.Text = "Refresh";
            this.btnLamMoiNV.UseVisualStyleBackColor = true;
            this.btnLamMoiNV.Click += new System.EventHandler(this.btnLamMoiNV_Click);
            // 
            // btnUndoNV
            // 
            this.btnUndoNV.Location = new System.Drawing.Point(415, 20);
            this.btnUndoNV.Name = "btnUndoNV";
            this.btnUndoNV.Size = new System.Drawing.Size(75, 23);
            this.btnUndoNV.TabIndex = 22;
            this.btnUndoNV.Text = "Undo";
            this.btnUndoNV.UseVisualStyleBackColor = true;
            this.btnUndoNV.Click += new System.EventHandler(this.btnUndoNV_Click);
            // 
            // btnSuaNV
            // 
            this.btnSuaNV.Location = new System.Drawing.Point(283, 20);
            this.btnSuaNV.Name = "btnSuaNV";
            this.btnSuaNV.Size = new System.Drawing.Size(75, 23);
            this.btnSuaNV.TabIndex = 21;
            this.btnSuaNV.Text = "Sửa";
            this.btnSuaNV.UseVisualStyleBackColor = true;
            this.btnSuaNV.Click += new System.EventHandler(this.btnSuaNV_Click);
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Location = new System.Drawing.Point(149, 20);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(75, 23);
            this.btnXoaNV.TabIndex = 20;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // btnThemNV
            // 
            this.btnThemNV.Location = new System.Drawing.Point(27, 20);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(75, 23);
            this.btnThemNV.TabIndex = 19;
            this.btnThemNV.Text = "Thêm";
            this.btnThemNV.UseVisualStyleBackColor = true;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnXoaCP);
            this.tabPage2.Controls.Add(this.btnSuaCP);
            this.tabPage2.Controls.Add(this.btnThoatCP);
            this.tabPage2.Controls.Add(this.btnThemCP);
            this.tabPage2.Controls.Add(this.dgvCoPhieu);
            this.tabPage2.Controls.Add(this.gbCoPhieu);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(775, 515);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cổ phiếu";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnXoaCP
            // 
            this.btnXoaCP.Location = new System.Drawing.Point(229, 30);
            this.btnXoaCP.Margin = new System.Windows.Forms.Padding(2);
            this.btnXoaCP.Name = "btnXoaCP";
            this.btnXoaCP.Size = new System.Drawing.Size(58, 26);
            this.btnXoaCP.TabIndex = 14;
            this.btnXoaCP.Text = "Xóa";
            this.btnXoaCP.UseVisualStyleBackColor = true;
            this.btnXoaCP.Click += new System.EventHandler(this.btnXoaCP_Click);
            // 
            // btnSuaCP
            // 
            this.btnSuaCP.Location = new System.Drawing.Point(447, 30);
            this.btnSuaCP.Margin = new System.Windows.Forms.Padding(2);
            this.btnSuaCP.Name = "btnSuaCP";
            this.btnSuaCP.Size = new System.Drawing.Size(58, 26);
            this.btnSuaCP.TabIndex = 13;
            this.btnSuaCP.Text = "Sửa";
            this.btnSuaCP.UseVisualStyleBackColor = true;
            this.btnSuaCP.Click += new System.EventHandler(this.btnSuaCP_Click);
            // 
            // btnThoatCP
            // 
            this.btnThoatCP.Location = new System.Drawing.Point(686, 30);
            this.btnThoatCP.Margin = new System.Windows.Forms.Padding(2);
            this.btnThoatCP.Name = "btnThoatCP";
            this.btnThoatCP.Size = new System.Drawing.Size(57, 26);
            this.btnThoatCP.TabIndex = 12;
            this.btnThoatCP.Text = "Thoát";
            this.btnThoatCP.UseVisualStyleBackColor = true;
            this.btnThoatCP.Click += new System.EventHandler(this.btnThoatCP_Click);
            // 
            // btnThemCP
            // 
            this.btnThemCP.Location = new System.Drawing.Point(42, 30);
            this.btnThemCP.Margin = new System.Windows.Forms.Padding(2);
            this.btnThemCP.Name = "btnThemCP";
            this.btnThemCP.Size = new System.Drawing.Size(57, 26);
            this.btnThemCP.TabIndex = 11;
            this.btnThemCP.Text = "Thêm";
            this.btnThemCP.UseVisualStyleBackColor = true;
            this.btnThemCP.Click += new System.EventHandler(this.btnThemCP_Click);
            // 
            // dgvCoPhieu
            // 
            this.dgvCoPhieu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCoPhieu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaCP,
            this.TenCP,
            this.DiaChiCP,
            this.SDTCP,
            this.Fax,
            this.Email,
            this.Website,
            this.SoLuongCP});
            this.dgvCoPhieu.Location = new System.Drawing.Point(31, 325);
            this.dgvCoPhieu.Margin = new System.Windows.Forms.Padding(2);
            this.dgvCoPhieu.Name = "dgvCoPhieu";
            this.dgvCoPhieu.RowHeadersWidth = 51;
            this.dgvCoPhieu.RowTemplate.Height = 24;
            this.dgvCoPhieu.Size = new System.Drawing.Size(724, 122);
            this.dgvCoPhieu.TabIndex = 10;
            this.dgvCoPhieu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCoPhieu_CellContentClick);
            // 
            // MaCP
            // 
            this.MaCP.DataPropertyName = "MaCP";
            this.MaCP.HeaderText = "Mã cổ phiếu";
            this.MaCP.MinimumWidth = 6;
            this.MaCP.Name = "MaCP";
            this.MaCP.Width = 125;
            // 
            // TenCP
            // 
            this.TenCP.DataPropertyName = "TenCP";
            this.TenCP.HeaderText = "Tên cổ phiếu";
            this.TenCP.Name = "TenCP";
            // 
            // DiaChiCP
            // 
            this.DiaChiCP.DataPropertyName = "DiaChi";
            this.DiaChiCP.HeaderText = "Địa chỉ";
            this.DiaChiCP.MinimumWidth = 6;
            this.DiaChiCP.Name = "DiaChiCP";
            this.DiaChiCP.Width = 125;
            // 
            // SDTCP
            // 
            this.SDTCP.DataPropertyName = "SoDT";
            this.SDTCP.HeaderText = "Số điện thoại";
            this.SDTCP.MinimumWidth = 6;
            this.SDTCP.Name = "SDTCP";
            this.SDTCP.Width = 125;
            // 
            // Fax
            // 
            this.Fax.DataPropertyName = "Fax";
            this.Fax.HeaderText = "Fax";
            this.Fax.MinimumWidth = 6;
            this.Fax.Name = "Fax";
            this.Fax.Width = 125;
            // 
            // Email
            // 
            this.Email.DataPropertyName = "Email";
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            // 
            // Website
            // 
            this.Website.DataPropertyName = "DiaChiWebsite";
            this.Website.HeaderText = "Website";
            this.Website.MinimumWidth = 6;
            this.Website.Name = "Website";
            this.Website.Width = 125;
            // 
            // SoLuongCP
            // 
            this.SoLuongCP.DataPropertyName = "SoLuongCP";
            this.SoLuongCP.HeaderText = "Số lượng";
            this.SoLuongCP.MinimumWidth = 6;
            this.SoLuongCP.Name = "SoLuongCP";
            this.SoLuongCP.Width = 125;
            // 
            // gbCoPhieu
            // 
            this.gbCoPhieu.Controls.Add(this.txtEmail);
            this.gbCoPhieu.Controls.Add(this.label19);
            this.gbCoPhieu.Controls.Add(this.label16);
            this.gbCoPhieu.Controls.Add(this.label15);
            this.gbCoPhieu.Controls.Add(this.label14);
            this.gbCoPhieu.Controls.Add(this.label13);
            this.gbCoPhieu.Controls.Add(this.label12);
            this.gbCoPhieu.Controls.Add(this.label17);
            this.gbCoPhieu.Controls.Add(this.btnHuyCP);
            this.gbCoPhieu.Controls.Add(this.btnXacNhanCP);
            this.gbCoPhieu.Controls.Add(this.label18);
            this.gbCoPhieu.Controls.Add(this.txtSoLuongCP);
            this.gbCoPhieu.Controls.Add(this.txtWebsiteCT);
            this.gbCoPhieu.Controls.Add(this.txtTenCP);
            this.gbCoPhieu.Controls.Add(this.txtDiaChiCT);
            this.gbCoPhieu.Controls.Add(this.txtSDTCT);
            this.gbCoPhieu.Controls.Add(this.txtFaxCT);
            this.gbCoPhieu.Controls.Add(this.txtMaCP);
            this.gbCoPhieu.Location = new System.Drawing.Point(33, 87);
            this.gbCoPhieu.Margin = new System.Windows.Forms.Padding(2);
            this.gbCoPhieu.Name = "gbCoPhieu";
            this.gbCoPhieu.Padding = new System.Windows.Forms.Padding(2);
            this.gbCoPhieu.Size = new System.Drawing.Size(722, 190);
            this.gbCoPhieu.TabIndex = 9;
            this.gbCoPhieu.TabStop = false;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(457, 115);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(234, 21);
            this.txtEmail.TabIndex = 12;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(404, 118);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 13);
            this.label19.TabIndex = 19;
            this.label19.Text = "Email:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(479, 36);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 13);
            this.label16.TabIndex = 18;
            this.label16.Text = "Số lượng:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(479, 77);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "Website:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(272, 77);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Số fax:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(272, 36);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "Số điện thoại:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 115);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Địa chỉ:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(33, 77);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 13);
            this.label17.TabIndex = 13;
            this.label17.Text = "Tên cổ phiếu:";
            // 
            // btnHuyCP
            // 
            this.btnHuyCP.Location = new System.Drawing.Point(394, 148);
            this.btnHuyCP.Margin = new System.Windows.Forms.Padding(2);
            this.btnHuyCP.Name = "btnHuyCP";
            this.btnHuyCP.Size = new System.Drawing.Size(57, 26);
            this.btnHuyCP.TabIndex = 3;
            this.btnHuyCP.Text = "Hủy";
            this.btnHuyCP.UseVisualStyleBackColor = true;
            this.btnHuyCP.Click += new System.EventHandler(this.btnHuyCP_Click);
            // 
            // btnXacNhanCP
            // 
            this.btnXacNhanCP.Location = new System.Drawing.Point(270, 148);
            this.btnXacNhanCP.Margin = new System.Windows.Forms.Padding(2);
            this.btnXacNhanCP.Name = "btnXacNhanCP";
            this.btnXacNhanCP.Size = new System.Drawing.Size(64, 26);
            this.btnXacNhanCP.TabIndex = 13;
            this.btnXacNhanCP.Text = "Xác Nhận";
            this.btnXacNhanCP.UseVisualStyleBackColor = true;
            this.btnXacNhanCP.Click += new System.EventHandler(this.btnXacNhanCP_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(33, 36);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 13);
            this.label18.TabIndex = 12;
            this.label18.Text = "Mã cổ phiếu:";
            // 
            // txtSoLuongCP
            // 
            this.txtSoLuongCP.Location = new System.Drawing.Point(536, 33);
            this.txtSoLuongCP.Margin = new System.Windows.Forms.Padding(2);
            this.txtSoLuongCP.Name = "txtSoLuongCP";
            this.txtSoLuongCP.Size = new System.Drawing.Size(155, 21);
            this.txtSoLuongCP.TabIndex = 10;
            // 
            // txtWebsiteCT
            // 
            this.txtWebsiteCT.Location = new System.Drawing.Point(536, 75);
            this.txtWebsiteCT.Margin = new System.Windows.Forms.Padding(2);
            this.txtWebsiteCT.Name = "txtWebsiteCT";
            this.txtWebsiteCT.Size = new System.Drawing.Size(155, 21);
            this.txtWebsiteCT.TabIndex = 11;
            // 
            // txtTenCP
            // 
            this.txtTenCP.Location = new System.Drawing.Point(109, 75);
            this.txtTenCP.Margin = new System.Windows.Forms.Padding(2);
            this.txtTenCP.Name = "txtTenCP";
            this.txtTenCP.Size = new System.Drawing.Size(145, 21);
            this.txtTenCP.TabIndex = 6;
            // 
            // txtDiaChiCT
            // 
            this.txtDiaChiCT.Location = new System.Drawing.Point(109, 115);
            this.txtDiaChiCT.Margin = new System.Windows.Forms.Padding(2);
            this.txtDiaChiCT.Name = "txtDiaChiCT";
            this.txtDiaChiCT.Size = new System.Drawing.Size(207, 21);
            this.txtDiaChiCT.TabIndex = 7;
            // 
            // txtSDTCT
            // 
            this.txtSDTCT.Location = new System.Drawing.Point(363, 33);
            this.txtSDTCT.Margin = new System.Windows.Forms.Padding(2);
            this.txtSDTCT.Name = "txtSDTCT";
            this.txtSDTCT.Size = new System.Drawing.Size(76, 21);
            this.txtSDTCT.TabIndex = 8;
            // 
            // txtFaxCT
            // 
            this.txtFaxCT.Location = new System.Drawing.Point(363, 75);
            this.txtFaxCT.Margin = new System.Windows.Forms.Padding(2);
            this.txtFaxCT.Name = "txtFaxCT";
            this.txtFaxCT.Size = new System.Drawing.Size(76, 21);
            this.txtFaxCT.TabIndex = 9;
            // 
            // txtMaCP
            // 
            this.txtMaCP.Location = new System.Drawing.Point(109, 33);
            this.txtMaCP.Margin = new System.Windows.Forms.Padding(2);
            this.txtMaCP.Name = "txtMaCP";
            this.txtMaCP.Size = new System.Drawing.Size(145, 21);
            this.txtMaCP.TabIndex = 5;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnHuyGiaCP);
            this.tabPage3.Controls.Add(this.btnHuyQD);
            this.tabPage3.Controls.Add(this.btnSuaGia);
            this.tabPage3.Controls.Add(this.btnThemGia);
            this.tabPage3.Controls.Add(this.dgvCapNhat);
            this.tabPage3.Controls.Add(this.btnSuaQuyDinh);
            this.tabPage3.Controls.Add(this.gbGiaCP);
            this.tabPage3.Controls.Add(this.gbQuyDinh);
            this.tabPage3.Controls.Add(this.dgvGiaCP);
            this.tabPage3.Controls.Add(this.btnThemQuyDinh);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(775, 515);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Cập nhật giá cổ phiếu";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnHuyGiaCP
            // 
            this.btnHuyGiaCP.Location = new System.Drawing.Point(676, 21);
            this.btnHuyGiaCP.Name = "btnHuyGiaCP";
            this.btnHuyGiaCP.Size = new System.Drawing.Size(75, 23);
            this.btnHuyGiaCP.TabIndex = 40;
            this.btnHuyGiaCP.Text = "Hủy";
            this.btnHuyGiaCP.UseVisualStyleBackColor = true;
            this.btnHuyGiaCP.Click += new System.EventHandler(this.btnHuyGiaCP_Click);
            // 
            // btnHuyQD
            // 
            this.btnHuyQD.Location = new System.Drawing.Point(264, 21);
            this.btnHuyQD.Name = "btnHuyQD";
            this.btnHuyQD.Size = new System.Drawing.Size(75, 23);
            this.btnHuyQD.TabIndex = 39;
            this.btnHuyQD.Text = "Hủy";
            this.btnHuyQD.UseVisualStyleBackColor = true;
            this.btnHuyQD.Click += new System.EventHandler(this.btnHuyQD_Click);
            // 
            // btnSuaGia
            // 
            this.btnSuaGia.Location = new System.Drawing.Point(556, 21);
            this.btnSuaGia.Name = "btnSuaGia";
            this.btnSuaGia.Size = new System.Drawing.Size(94, 23);
            this.btnSuaGia.TabIndex = 38;
            this.btnSuaGia.Text = "Sửa giá cổ phiếu";
            this.btnSuaGia.UseVisualStyleBackColor = true;
            this.btnSuaGia.Click += new System.EventHandler(this.btnSuaGia_Click);
            // 
            // btnThemGia
            // 
            this.btnThemGia.Location = new System.Drawing.Point(400, 21);
            this.btnThemGia.Name = "btnThemGia";
            this.btnThemGia.Size = new System.Drawing.Size(107, 23);
            this.btnThemGia.TabIndex = 37;
            this.btnThemGia.Text = "Thêm giá cổ phiếu";
            this.btnThemGia.UseVisualStyleBackColor = true;
            this.btnThemGia.Click += new System.EventHandler(this.btnThemGia_Click);
            // 
            // dgvCapNhat
            // 
            this.dgvCapNhat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCapNhat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaSGD,
            this.Ngay,
            this.MoTaQuyDinh,
            this.GiaQuyDinh});
            this.dgvCapNhat.Location = new System.Drawing.Point(20, 349);
            this.dgvCapNhat.Margin = new System.Windows.Forms.Padding(2);
            this.dgvCapNhat.Name = "dgvCapNhat";
            this.dgvCapNhat.RowHeadersWidth = 51;
            this.dgvCapNhat.RowTemplate.Height = 24;
            this.dgvCapNhat.Size = new System.Drawing.Size(352, 122);
            this.dgvCapNhat.TabIndex = 36;
            this.dgvCapNhat.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCapNhat_CellContentClick);
            // 
            // MaSGD
            // 
            this.MaSGD.DataPropertyName = "MaSGD";
            this.MaSGD.HeaderText = "Mã sàn";
            this.MaSGD.MinimumWidth = 6;
            this.MaSGD.Name = "MaSGD";
            this.MaSGD.Width = 125;
            // 
            // Ngay
            // 
            this.Ngay.DataPropertyName = "Ngay";
            this.Ngay.HeaderText = "Ngày";
            this.Ngay.MinimumWidth = 6;
            this.Ngay.Name = "Ngay";
            this.Ngay.Width = 125;
            // 
            // MoTaQuyDinh
            // 
            this.MoTaQuyDinh.DataPropertyName = "MoTaQuyDinh";
            this.MoTaQuyDinh.HeaderText = "Mô tả quy định";
            this.MoTaQuyDinh.MinimumWidth = 6;
            this.MoTaQuyDinh.Name = "MoTaQuyDinh";
            this.MoTaQuyDinh.Width = 125;
            // 
            // GiaQuyDinh
            // 
            this.GiaQuyDinh.DataPropertyName = "GiaQuyDinh";
            this.GiaQuyDinh.HeaderText = "Giá quy định";
            this.GiaQuyDinh.Name = "GiaQuyDinh";
            // 
            // btnSuaQuyDinh
            // 
            this.btnSuaQuyDinh.Location = new System.Drawing.Point(140, 19);
            this.btnSuaQuyDinh.Margin = new System.Windows.Forms.Padding(2);
            this.btnSuaQuyDinh.Name = "btnSuaQuyDinh";
            this.btnSuaQuyDinh.Size = new System.Drawing.Size(99, 27);
            this.btnSuaQuyDinh.TabIndex = 35;
            this.btnSuaQuyDinh.Text = "Sửa quy định";
            this.btnSuaQuyDinh.UseVisualStyleBackColor = true;
            this.btnSuaQuyDinh.Click += new System.EventHandler(this.btnSuaQuyDinh_Click);
            // 
            // gbGiaCP
            // 
            this.gbGiaCP.Controls.Add(this.dtpNgay1);
            this.gbGiaCP.Controls.Add(this.btnRefreshGiaCP);
            this.gbGiaCP.Controls.Add(this.txtGiaDongCua);
            this.gbGiaCP.Controls.Add(this.label29);
            this.gbGiaCP.Controls.Add(this.txtGiaSan);
            this.gbGiaCP.Controls.Add(this.txtGiaThamChieu);
            this.gbGiaCP.Controls.Add(this.cmbCP);
            this.gbGiaCP.Controls.Add(this.label24);
            this.gbGiaCP.Controls.Add(this.label23);
            this.gbGiaCP.Controls.Add(this.btnXacNhanGia);
            this.gbGiaCP.Controls.Add(this.txtGiaTran);
            this.gbGiaCP.Controls.Add(this.label28);
            this.gbGiaCP.Controls.Add(this.label27);
            this.gbGiaCP.Controls.Add(this.label26);
            this.gbGiaCP.Location = new System.Drawing.Point(400, 50);
            this.gbGiaCP.Margin = new System.Windows.Forms.Padding(2);
            this.gbGiaCP.Name = "gbGiaCP";
            this.gbGiaCP.Padding = new System.Windows.Forms.Padding(2);
            this.gbGiaCP.Size = new System.Drawing.Size(360, 263);
            this.gbGiaCP.TabIndex = 32;
            this.gbGiaCP.TabStop = false;
            // 
            // dtpNgay1
            // 
            this.dtpNgay1.CustomFormat = "yyyy-MM-dd";
            this.dtpNgay1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgay1.Location = new System.Drawing.Point(120, 49);
            this.dtpNgay1.Name = "dtpNgay1";
            this.dtpNgay1.Size = new System.Drawing.Size(100, 21);
            this.dtpNgay1.TabIndex = 41;
            this.dtpNgay1.Value = new System.DateTime(2020, 12, 8, 0, 0, 0, 0);
            // 
            // btnRefreshGiaCP
            // 
            this.btnRefreshGiaCP.Location = new System.Drawing.Point(40, 224);
            this.btnRefreshGiaCP.Name = "btnRefreshGiaCP";
            this.btnRefreshGiaCP.Size = new System.Drawing.Size(75, 23);
            this.btnRefreshGiaCP.TabIndex = 40;
            this.btnRefreshGiaCP.Text = "Refresh";
            this.btnRefreshGiaCP.UseVisualStyleBackColor = true;
            this.btnRefreshGiaCP.Click += new System.EventHandler(this.btnRefreshGiaCP_Click);
            // 
            // txtGiaDongCua
            // 
            this.txtGiaDongCua.Location = new System.Drawing.Point(120, 197);
            this.txtGiaDongCua.Name = "txtGiaDongCua";
            this.txtGiaDongCua.Size = new System.Drawing.Size(100, 21);
            this.txtGiaDongCua.TabIndex = 34;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(15, 200);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(74, 13);
            this.label29.TabIndex = 39;
            this.label29.Text = "Giá đóng cửa:";
            // 
            // txtGiaSan
            // 
            this.txtGiaSan.Location = new System.Drawing.Point(120, 160);
            this.txtGiaSan.Name = "txtGiaSan";
            this.txtGiaSan.Size = new System.Drawing.Size(100, 21);
            this.txtGiaSan.TabIndex = 33;
            // 
            // txtGiaThamChieu
            // 
            this.txtGiaThamChieu.Location = new System.Drawing.Point(120, 126);
            this.txtGiaThamChieu.Name = "txtGiaThamChieu";
            this.txtGiaThamChieu.Size = new System.Drawing.Size(100, 21);
            this.txtGiaThamChieu.TabIndex = 32;
            // 
            // cmbCP
            // 
            this.cmbCP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCP.FormattingEnabled = true;
            this.cmbCP.Location = new System.Drawing.Point(120, 17);
            this.cmbCP.Name = "cmbCP";
            this.cmbCP.Size = new System.Drawing.Size(151, 21);
            this.cmbCP.TabIndex = 37;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 163);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 13);
            this.label24.TabIndex = 36;
            this.label24.Text = "Giá sàn:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(15, 129);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 13);
            this.label23.TabIndex = 35;
            this.label23.Text = "Giá tham chiếu:";
            // 
            // btnXacNhanGia
            // 
            this.btnXacNhanGia.Location = new System.Drawing.Point(267, 221);
            this.btnXacNhanGia.Margin = new System.Windows.Forms.Padding(2);
            this.btnXacNhanGia.Name = "btnXacNhanGia";
            this.btnXacNhanGia.Size = new System.Drawing.Size(64, 28);
            this.btnXacNhanGia.TabIndex = 35;
            this.btnXacNhanGia.Text = "Xác Nhận";
            this.btnXacNhanGia.UseVisualStyleBackColor = true;
            this.btnXacNhanGia.Click += new System.EventHandler(this.btnXacNhanGia_Click);
            // 
            // txtGiaTran
            // 
            this.txtGiaTran.Location = new System.Drawing.Point(120, 90);
            this.txtGiaTran.Margin = new System.Windows.Forms.Padding(2);
            this.txtGiaTran.Name = "txtGiaTran";
            this.txtGiaTran.Size = new System.Drawing.Size(100, 21);
            this.txtGiaTran.TabIndex = 31;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(15, 20);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(68, 13);
            this.label28.TabIndex = 30;
            this.label28.Text = "Mã cổ phiếu:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(15, 55);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 13);
            this.label27.TabIndex = 29;
            this.label27.Text = "Ngày/Giờ:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(15, 93);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(49, 13);
            this.label26.TabIndex = 28;
            this.label26.Text = "Giá trần:";
            // 
            // gbQuyDinh
            // 
            this.gbQuyDinh.Controls.Add(this.dtpNgayGio);
            this.gbQuyDinh.Controls.Add(this.cmbQuyDinh);
            this.gbQuyDinh.Controls.Add(this.txtGiaQuyDinh);
            this.gbQuyDinh.Controls.Add(this.label22);
            this.gbQuyDinh.Controls.Add(this.label20);
            this.gbQuyDinh.Controls.Add(this.btnXacNhanQD);
            this.gbQuyDinh.Controls.Add(this.txtMaSan);
            this.gbQuyDinh.Controls.Add(this.label25);
            this.gbQuyDinh.Controls.Add(this.label21);
            this.gbQuyDinh.Location = new System.Drawing.Point(20, 50);
            this.gbQuyDinh.Margin = new System.Windows.Forms.Padding(2);
            this.gbQuyDinh.Name = "gbQuyDinh";
            this.gbQuyDinh.Padding = new System.Windows.Forms.Padding(2);
            this.gbQuyDinh.Size = new System.Drawing.Size(352, 263);
            this.gbQuyDinh.TabIndex = 32;
            this.gbQuyDinh.TabStop = false;
            // 
            // dtpNgayGio
            // 
            this.dtpNgayGio.CustomFormat = "yyyy-MM-dd";
            this.dtpNgayGio.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayGio.Location = new System.Drawing.Point(119, 49);
            this.dtpNgayGio.Name = "dtpNgayGio";
            this.dtpNgayGio.Size = new System.Drawing.Size(100, 21);
            this.dtpNgayGio.TabIndex = 32;
            this.dtpNgayGio.Value = new System.DateTime(2020, 12, 8, 0, 0, 0, 0);
            // 
            // cmbQuyDinh
            // 
            this.cmbQuyDinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuyDinh.FormattingEnabled = true;
            this.cmbQuyDinh.Items.AddRange(new object[] {
            "Biên độ giá",
            "Bước giá đặt lệnh",
            "Lô lệnh tối thiểu"});
            this.cmbQuyDinh.Location = new System.Drawing.Point(120, 93);
            this.cmbQuyDinh.Name = "cmbQuyDinh";
            this.cmbQuyDinh.Size = new System.Drawing.Size(199, 21);
            this.cmbQuyDinh.TabIndex = 31;
            // 
            // txtGiaQuyDinh
            // 
            this.txtGiaQuyDinh.Location = new System.Drawing.Point(120, 140);
            this.txtGiaQuyDinh.Name = "txtGiaQuyDinh";
            this.txtGiaQuyDinh.Size = new System.Drawing.Size(199, 21);
            this.txtGiaQuyDinh.TabIndex = 30;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(11, 143);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 13);
            this.label22.TabIndex = 29;
            this.label22.Text = "Giá của quy định:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(11, 96);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 13);
            this.label20.TabIndex = 27;
            this.label20.Text = "Mô tả quy định:";
            // 
            // btnXacNhanQD
            // 
            this.btnXacNhanQD.Location = new System.Drawing.Point(238, 172);
            this.btnXacNhanQD.Margin = new System.Windows.Forms.Padding(2);
            this.btnXacNhanQD.Name = "btnXacNhanQD";
            this.btnXacNhanQD.Size = new System.Drawing.Size(65, 28);
            this.btnXacNhanQD.TabIndex = 25;
            this.btnXacNhanQD.Text = "Xác Nhận";
            this.btnXacNhanQD.UseVisualStyleBackColor = true;
            this.btnXacNhanQD.Click += new System.EventHandler(this.btnXacNhanQD_Click);
            // 
            // txtMaSan
            // 
            this.txtMaSan.Location = new System.Drawing.Point(120, 17);
            this.txtMaSan.Margin = new System.Windows.Forms.Padding(2);
            this.txtMaSan.Name = "txtMaSan";
            this.txtMaSan.Size = new System.Drawing.Size(99, 21);
            this.txtMaSan.TabIndex = 20;
            this.txtMaSan.Text = "HNX";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(11, 55);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(55, 13);
            this.label25.TabIndex = 19;
            this.label25.Text = "Ngày/Giờ:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(11, 20);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 15;
            this.label21.Text = "Mã sàn:";
            // 
            // dgvGiaCP
            // 
            this.dgvGiaCP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGiaCP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaCP1,
            this.NgayGio,
            this.GiaSan,
            this.GiaThamChieu,
            this.GiaTran,
            this.GiaDongCua});
            this.dgvGiaCP.Location = new System.Drawing.Point(400, 349);
            this.dgvGiaCP.Margin = new System.Windows.Forms.Padding(2);
            this.dgvGiaCP.Name = "dgvGiaCP";
            this.dgvGiaCP.RowHeadersWidth = 51;
            this.dgvGiaCP.RowTemplate.Height = 24;
            this.dgvGiaCP.Size = new System.Drawing.Size(360, 122);
            this.dgvGiaCP.TabIndex = 31;
            this.dgvGiaCP.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGiaCP_CellContentClick);
            // 
            // MaCP1
            // 
            this.MaCP1.DataPropertyName = "MaCP";
            this.MaCP1.HeaderText = "Mã cổ phiếu";
            this.MaCP1.MinimumWidth = 6;
            this.MaCP1.Name = "MaCP1";
            this.MaCP1.Width = 125;
            // 
            // NgayGio
            // 
            this.NgayGio.DataPropertyName = "NgayGio";
            this.NgayGio.HeaderText = "Ngày/Giờ";
            this.NgayGio.MinimumWidth = 6;
            this.NgayGio.Name = "NgayGio";
            this.NgayGio.Width = 125;
            // 
            // GiaSan
            // 
            this.GiaSan.DataPropertyName = "GiaSan";
            this.GiaSan.HeaderText = "Giá sàn ";
            this.GiaSan.MinimumWidth = 6;
            this.GiaSan.Name = "GiaSan";
            this.GiaSan.Width = 125;
            // 
            // GiaThamChieu
            // 
            this.GiaThamChieu.DataPropertyName = "GiaThamChieu";
            this.GiaThamChieu.HeaderText = "Giá tham chiếu";
            this.GiaThamChieu.MinimumWidth = 6;
            this.GiaThamChieu.Name = "GiaThamChieu";
            this.GiaThamChieu.Width = 125;
            // 
            // GiaTran
            // 
            this.GiaTran.DataPropertyName = "GiaTran";
            this.GiaTran.HeaderText = "Giá trần";
            this.GiaTran.MinimumWidth = 6;
            this.GiaTran.Name = "GiaTran";
            this.GiaTran.Width = 125;
            // 
            // GiaDongCua
            // 
            this.GiaDongCua.DataPropertyName = "GiaDongCua";
            this.GiaDongCua.HeaderText = "Giá đóng cửa";
            this.GiaDongCua.Name = "GiaDongCua";
            // 
            // btnThemQuyDinh
            // 
            this.btnThemQuyDinh.Location = new System.Drawing.Point(20, 18);
            this.btnThemQuyDinh.Margin = new System.Windows.Forms.Padding(2);
            this.btnThemQuyDinh.Name = "btnThemQuyDinh";
            this.btnThemQuyDinh.Size = new System.Drawing.Size(93, 28);
            this.btnThemQuyDinh.TabIndex = 29;
            this.btnThemQuyDinh.Text = "Thêm quy định";
            this.btnThemQuyDinh.UseVisualStyleBackColor = true;
            this.btnThemQuyDinh.Click += new System.EventHandler(this.btnThemQuyDinh_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnThoat);
            this.tabPage4.Controls.Add(this.btnRefresh);
            this.tabPage4.Controls.Add(this.dgvLenhDat);
            this.tabPage4.Controls.Add(this.dgvKhopLenh);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(775, 515);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Xem dữ liệu khớp lệnh";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(492, 239);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(75, 36);
            this.btnThoat.TabIndex = 3;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(205, 239);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 36);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // dgvLenhDat
            // 
            this.dgvLenhDat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLenhDat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaLD,
            this.SoLuongDat,
            this.GiaDat,
            this.NgayGio1,
            this.MaLL,
            this.MaTKNH,
            this.MaLGD,
            this.MaTT,
            this.MaCP2});
            this.dgvLenhDat.Location = new System.Drawing.Point(29, 32);
            this.dgvLenhDat.Name = "dgvLenhDat";
            this.dgvLenhDat.Size = new System.Drawing.Size(716, 201);
            this.dgvLenhDat.TabIndex = 1;
            // 
            // dgvKhopLenh
            // 
            this.dgvKhopLenh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhopLenh.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaKL,
            this.NgayGio2,
            this.SoLuongKhop,
            this.PhiGiaoDich,
            this.GiaKhop,
            this.MaLD1});
            this.dgvKhopLenh.Location = new System.Drawing.Point(29, 281);
            this.dgvKhopLenh.Name = "dgvKhopLenh";
            this.dgvKhopLenh.Size = new System.Drawing.Size(716, 195);
            this.dgvKhopLenh.TabIndex = 0;
            // 
            // MaKL
            // 
            this.MaKL.DataPropertyName = "MaKL";
            this.MaKL.HeaderText = "Mã khớp lệnh";
            this.MaKL.Name = "MaKL";
            // 
            // NgayGio2
            // 
            this.NgayGio2.DataPropertyName = "NgayGio";
            this.NgayGio2.HeaderText = "Ngày giờ khớp";
            this.NgayGio2.Name = "NgayGio2";
            // 
            // SoLuongKhop
            // 
            this.SoLuongKhop.DataPropertyName = "SoLuongKhop";
            this.SoLuongKhop.HeaderText = "Số lượng khớp";
            this.SoLuongKhop.Name = "SoLuongKhop";
            // 
            // PhiGiaoDich
            // 
            this.PhiGiaoDich.DataPropertyName = "PhiGiaoDich";
            this.PhiGiaoDich.HeaderText = "Phí giao dịch";
            this.PhiGiaoDich.Name = "PhiGiaoDich";
            // 
            // GiaKhop
            // 
            this.GiaKhop.DataPropertyName = "GiaKhop";
            this.GiaKhop.HeaderText = "Giá Khớp";
            this.GiaKhop.Name = "GiaKhop";
            // 
            // MaLD1
            // 
            this.MaLD1.DataPropertyName = "MaLD";
            this.MaLD1.HeaderText = "Mã lệnh đặt";
            this.MaLD1.Name = "MaLD1";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.txtQuyen);
            this.tabPage5.Controls.Add(this.cmbMaNV);
            this.tabPage5.Controls.Add(this.btnThoatLG);
            this.tabPage5.Controls.Add(this.btnXacNhanLG);
            this.tabPage5.Controls.Add(this.label37);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.label39);
            this.tabPage5.Controls.Add(this.label40);
            this.tabPage5.Controls.Add(this.txtTenLG);
            this.tabPage5.Controls.Add(this.txtMKLG);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(775, 515);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Tạo login";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // txtQuyen
            // 
            this.txtQuyen.Location = new System.Drawing.Point(224, 90);
            this.txtQuyen.Name = "txtQuyen";
            this.txtQuyen.Size = new System.Drawing.Size(93, 21);
            this.txtQuyen.TabIndex = 38;
            this.txtQuyen.Text = "SANGIAODICH";
            // 
            // cmbMaNV
            // 
            this.cmbMaNV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaNV.FormattingEnabled = true;
            this.cmbMaNV.Location = new System.Drawing.Point(224, 173);
            this.cmbMaNV.Name = "cmbMaNV";
            this.cmbMaNV.Size = new System.Drawing.Size(93, 21);
            this.cmbMaNV.TabIndex = 37;
            // 
            // btnThoatLG
            // 
            this.btnThoatLG.Location = new System.Drawing.Point(461, 271);
            this.btnThoatLG.Name = "btnThoatLG";
            this.btnThoatLG.Size = new System.Drawing.Size(75, 23);
            this.btnThoatLG.TabIndex = 35;
            this.btnThoatLG.Text = "Thoát";
            this.btnThoatLG.UseVisualStyleBackColor = true;
            this.btnThoatLG.Click += new System.EventHandler(this.btnThoatLG_Click);
            // 
            // btnXacNhanLG
            // 
            this.btnXacNhanLG.Location = new System.Drawing.Point(213, 271);
            this.btnXacNhanLG.Name = "btnXacNhanLG";
            this.btnXacNhanLG.Size = new System.Drawing.Size(75, 23);
            this.btnXacNhanLG.TabIndex = 34;
            this.btnXacNhanLG.Text = "Xác nhận";
            this.btnXacNhanLG.UseVisualStyleBackColor = true;
            this.btnXacNhanLG.Click += new System.EventHandler(this.btnXacNhanLG_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(409, 93);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(83, 13);
            this.label37.TabIndex = 31;
            this.label37.Text = "Tên đăng nhập:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(132, 93);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(71, 13);
            this.label38.TabIndex = 30;
            this.label38.Text = "Nhóm quyền:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(148, 176);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(25, 13);
            this.label39.TabIndex = 29;
            this.label39.Text = "Mã:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(409, 176);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(55, 13);
            this.label40.TabIndex = 28;
            this.label40.Text = "Mật khẩu:";
            // 
            // txtTenLG
            // 
            this.txtTenLG.Location = new System.Drawing.Point(507, 88);
            this.txtTenLG.Margin = new System.Windows.Forms.Padding(2);
            this.txtTenLG.Name = "txtTenLG";
            this.txtTenLG.Size = new System.Drawing.Size(86, 21);
            this.txtTenLG.TabIndex = 32;
            // 
            // txtMKLG
            // 
            this.txtMKLG.Location = new System.Drawing.Point(507, 173);
            this.txtMKLG.Margin = new System.Windows.Forms.Padding(2);
            this.txtMKLG.Name = "txtMKLG";
            this.txtMKLG.PasswordChar = '*';
            this.txtMKLG.Size = new System.Drawing.Size(86, 21);
            this.txtMKLG.TabIndex = 33;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.LBSan);
            this.panel1.Controls.Add(this.LBQuyen);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.LBTen);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.LBMa);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 555);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(783, 105);
            this.panel1.TabIndex = 1;
            // 
            // LBSan
            // 
            this.LBSan.AutoSize = true;
            this.LBSan.Location = new System.Drawing.Point(619, 48);
            this.LBSan.Name = "LBSan";
            this.LBSan.Size = new System.Drawing.Size(35, 13);
            this.LBSan.TabIndex = 6;
            this.LBSan.Text = "label7";
            // 
            // LBQuyen
            // 
            this.LBQuyen.AutoSize = true;
            this.LBQuyen.Location = new System.Drawing.Point(441, 48);
            this.LBQuyen.Name = "LBQuyen";
            this.LBQuyen.Size = new System.Drawing.Size(35, 13);
            this.LBQuyen.TabIndex = 5;
            this.LBQuyen.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(392, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Quyền:";
            // 
            // LBTen
            // 
            this.LBTen.AutoSize = true;
            this.LBTen.Location = new System.Drawing.Point(249, 48);
            this.LBTen.Name = "LBTen";
            this.LBTen.Size = new System.Drawing.Size(35, 13);
            this.LBTen.TabIndex = 3;
            this.LBTen.Text = "label4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Họ và tên:";
            // 
            // LBMa
            // 
            this.LBMa.AutoSize = true;
            this.LBMa.Location = new System.Drawing.Point(43, 48);
            this.LBMa.Name = "LBMa";
            this.LBMa.Size = new System.Drawing.Size(35, 13);
            this.LBMa.TabIndex = 1;
            this.LBMa.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã:";
            // 
            // MaLD
            // 
            this.MaLD.DataPropertyName = "MaLD";
            this.MaLD.HeaderText = "Mã lệnh đặt";
            this.MaLD.Name = "MaLD";
            // 
            // SoLuongDat
            // 
            this.SoLuongDat.DataPropertyName = "SoLuongDat";
            this.SoLuongDat.HeaderText = "Số lượng đặt";
            this.SoLuongDat.Name = "SoLuongDat";
            // 
            // GiaDat
            // 
            this.GiaDat.DataPropertyName = "GiaDat";
            this.GiaDat.HeaderText = "Giá đặt";
            this.GiaDat.Name = "GiaDat";
            // 
            // NgayGio1
            // 
            this.NgayGio1.DataPropertyName = "NgayGio";
            this.NgayGio1.HeaderText = "Ngày giờ đặt";
            this.NgayGio1.Name = "NgayGio1";
            // 
            // MaLL
            // 
            this.MaLL.DataPropertyName = "MaLL";
            this.MaLL.HeaderText = "Mã loại lệnh";
            this.MaLL.Name = "MaLL";
            // 
            // MaTKNH
            // 
            this.MaTKNH.DataPropertyName = "MaTKNH";
            this.MaTKNH.HeaderText = "Mã tài khoản ngân hàng";
            this.MaTKNH.Name = "MaTKNH";
            this.MaTKNH.Width = 150;
            // 
            // MaLGD
            // 
            this.MaLGD.DataPropertyName = "MaLGD";
            this.MaLGD.HeaderText = "Mã loại giao dịch";
            this.MaLGD.Name = "MaLGD";
            this.MaLGD.Width = 130;
            // 
            // MaTT
            // 
            this.MaTT.DataPropertyName = "MaTT";
            this.MaTT.HeaderText = "Trạng thái";
            this.MaTT.Name = "MaTT";
            // 
            // MaCP2
            // 
            this.MaCP2.DataPropertyName = "MaCP";
            this.MaCP2.HeaderText = "Mã cổ phiếu";
            this.MaCP2.Name = "MaCP2";
            // 
            // FormSoGiaoDich
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 660);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormSoGiaoDich";
            this.Text = "FormSoGiaoDich";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormSoGiaoDich_FormClosing);
            this.Load += new System.EventHandler(this.FormSoGiaoDich_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.gbNhanVien.ResumeLayout(false);
            this.gbNhanVien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nghiCheckEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phaiCheckedit.Properties)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCoPhieu)).EndInit();
            this.gbCoPhieu.ResumeLayout(false);
            this.gbCoPhieu.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCapNhat)).EndInit();
            this.gbGiaCP.ResumeLayout(false);
            this.gbGiaCP.PerformLayout();
            this.gbQuyDinh.ResumeLayout(false);
            this.gbQuyDinh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGiaCP)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLenhDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhopLenh)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label LBMa;
        private System.Windows.Forms.Label LBSan;
        private System.Windows.Forms.Label LBQuyen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label LBTen;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox txtQuyen;
        private System.Windows.Forms.ComboBox cmbMaNV;
        private System.Windows.Forms.Button btnThoatLG;
        private System.Windows.Forms.Button btnXacNhanLG;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtTenLG;
        private System.Windows.Forms.TextBox txtMKLG;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.GroupBox gbNhanVien;
        private DevExpress.XtraEditors.CheckEdit nghiCheckEdit;
        private System.Windows.Forms.TextBox txtSDT;
        private DevExpress.XtraEditors.CheckEdit phaiCheckedit;
        private System.Windows.Forms.TextBox txtDiachiNV;
        private System.Windows.Forms.DateTimePicker dtpNgaysinhNV;
        private System.Windows.Forms.TextBox txtTenNV;
        private System.Windows.Forms.TextBox txtHoNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnThoatNV;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnLamMoiNV;
        private System.Windows.Forms.Button btnGhi;
        private System.Windows.Forms.Button btnUndoNV;
        private System.Windows.Forms.Button btnSuaNV;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.Button btnXoaCP;
        private System.Windows.Forms.Button btnSuaCP;
        private System.Windows.Forms.Button btnThoatCP;
        private System.Windows.Forms.Button btnThemCP;
        private System.Windows.Forms.DataGridView dgvCoPhieu;
        private System.Windows.Forms.GroupBox gbCoPhieu;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtSoLuongCP;
        private System.Windows.Forms.TextBox txtWebsiteCT;
        private System.Windows.Forms.TextBox txtTenCP;
        private System.Windows.Forms.TextBox txtDiaChiCT;
        private System.Windows.Forms.TextBox txtSDTCT;
        private System.Windows.Forms.TextBox txtFaxCT;
        private System.Windows.Forms.TextBox txtMaCP;
        private System.Windows.Forms.Button btnHuyCP;
        private System.Windows.Forms.Button btnXacNhanCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenNV;
        private System.Windows.Forms.DataGridViewCheckBoxColumn PhaiNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgaySinhNV;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChiNV;
        private System.Windows.Forms.DataGridViewCheckBoxColumn DaNghiViec;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiaChiCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn SDTCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Website;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongCP;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnSuaGia;
        private System.Windows.Forms.Button btnThemGia;
        private System.Windows.Forms.DataGridView dgvCapNhat;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSGD;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ngay;
        private System.Windows.Forms.DataGridViewTextBoxColumn MoTaQuyDinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaQuyDinh;
        private System.Windows.Forms.Button btnSuaQuyDinh;
        private System.Windows.Forms.GroupBox gbGiaCP;
        private System.Windows.Forms.TextBox txtGiaSan;
        private System.Windows.Forms.TextBox txtGiaThamChieu;
        private System.Windows.Forms.ComboBox cmbCP;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnXacNhanGia;
        private System.Windows.Forms.TextBox txtGiaTran;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox gbQuyDinh;
        private System.Windows.Forms.ComboBox cmbQuyDinh;
        private System.Windows.Forms.TextBox txtGiaQuyDinh;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnXacNhanQD;
        private System.Windows.Forms.TextBox txtMaSan;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView dgvGiaCP;
        private System.Windows.Forms.Button btnThemQuyDinh;
        private System.Windows.Forms.TextBox txtGiaDongCua;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCP1;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayGio;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaSan;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaThamChieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaTran;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaDongCua;
        private System.Windows.Forms.Button btnHuyGiaCP;
        private System.Windows.Forms.Button btnHuyQD;
        private System.Windows.Forms.Button btnRefreshGiaCP;
        private System.Windows.Forms.DataGridView dgvLenhDat;
        private System.Windows.Forms.DataGridView dgvKhopLenh;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKL;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayGio2;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongKhop;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhiGiaoDich;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaKhop;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLD1;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.DateTimePicker dtpNgayGio;
        private System.Windows.Forms.DateTimePicker dtpNgay1;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLD;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaDat;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayGio1;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLL;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTKNH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaLGD;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaTT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaCP2;
    }
}